sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"E/E/model/models",
	'sap/ui/model/json/JSONModel'
], function (UIComponent, Device, models, JSONModel) {
	"use strict";

	return UIComponent.extend("E.E.Component", {

		metadata: {
			manifest: "json"
			// config: {
			// 	fullWidht: true
			// }
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
	
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// enable routing
			this.getRouter().initialize();

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
			//	"target": ["TargetMaster", "SecondPage", "ThirdPage"] initially we target all three page when master page call so we change in here if we need mid view or left or right coulumn
			this.setModel(new JSONModel({
				layout: "MidColumnFullScreen"
					// layout: "OneColumn"
					//layout: "EndColumnFullScreen"
			}), "layoutMod");

		}
	});
});