sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"E/E/model/formatter",
	"sap/m/MessageBox",
	"sap/ui/model/Filter"
], function (Controller, formatter, MessageBox, Filter) {
	"use strict";

	return Controller.extend("E.E.controller.Inbox", {
		formatter: formatter,
		InboxList: [],
		types: {},
		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf E.E.view.Inbox
		 */
		onInit: function () {
			this.getOwnerComponent().getRouter().getRoute("Inbox").attachMatched(this.onNavToCurrentPage, this);
		},
		onNavToCurrentPage: function (e) {
		
			var that = this;
			that.types = e.getParameters('arguments').arguments;

			var filter1 = new sap.ui.model.Filter('UserFlag', 'EQ', "V");
			sap.ui.core.BusyIndicator.show();
			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/ZDWO_NX_VENDOR_SRV", true);
			oModel.read("/InboxSet", {
				filters: [filter1],
				success: function (oData, oResponse) {
		
					that.InboxList = oData.results;
					var array = [];
					that.InboxList.forEach(function (oIndex) {

						if (that.types.Code === oIndex.Rqstat) {
							// var array = [];
							array.push(oIndex);
						} else {
							console.log('Vendor Not Found')
						}

					});

					var oModel = new sap.ui.model.json.JSONModel();
					oModel.setData(array);

					// if (array[0].But2Visible === "false" && array[0].But4Visible === "false") {
					// 	that.getView().byId("Submit").setVisible(false);
					// 	that.getView().byId("Delete").setVisible(false);
					// }
					that.getView().setModel(oModel, "inModel");

					var title = new sap.ui.model.json.JSONModel();
					title.setData(that.types)
					that.getView().setModel(title, "title");

					var Count = new sap.ui.model.json.JSONModel();
					var obj = {
						count: array.length
					}
					Count.setData(obj)
					that.getView().setModel(Count, "Count");

					sap.ui.core.BusyIndicator.hide();
				},
				error: function (oData, response) {
					var data = oData.results;
					MessageBox.success("Data Load Error");
					sap.ui.core.BusyIndicator.hide();

				}

			});

		},
		onSearch: function (oEvent) {

			var aFilter;
			var sQuery = oEvent.getSource().getValue();
			if (sQuery && sQuery.length > 0) {
				aFilter = new sap.ui.model.Filter({
					filters: [
						new Filter("Descrip", sap.ui.model.FilterOperator.EQ, sQuery),
						new Filter("Docno", sap.ui.model.FilterOperator.EQ, sQuery),
						new Filter("Reqid", sap.ui.model.FilterOperator.EQ, sQuery),
					]
				});
			}
			// update list binding
			var UPLOAD = this.getView().byId("InboxList");
			var binding = UPLOAD.getBinding("items");
			binding.filter(aFilter);
		},
		click: function () {
		
			this.getOwnerComponent().getRouter().navTo('Master');

		},
		onUpdateFinished: function () {
		
			// var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/ZDWO_NX_VENDOR_SRV", true);
			// var sPath = "/InboxSet"
			// oModel.read(sPath, null, null, true, function (success) {
			// 		debugger;
			// 		// var zparse = JSON.parse(oCount);
			// 		var getRecAttchModel = new JSONModel();
			// 		getRecAttchModel.setData(success.results);
			// 		that.getView().setModel(getRecAttchModel, 'getRecAttchModel')

			// 	},
			// 	function (error) {

			// 		MessageBox.error("Data Load Error");
			// 	}
			// );
		},
		onListSelect: function (oEvent) {
	
			var oindex = oEvent.getSource().getSelectedItem("sId").sId.split("-")[2];
			var getDT = this.getView().getModel('inModel').getData()[oindex];
			this.getView().getModel("layoutMod").setProperty("/layout", "MidColumnFullScreen");
			var loRouter = sap.ui.core.UIComponent.getRouterFor(this);
			loRouter.navTo("Detview", {
				Docno: getDT.Docno,
				Mjahr: getDT.Mjahr

			});
		},

		Apv: function (oEvent) {
		
		},
		Rej: function (oEvent) {
		
		},

		mimeTypeToIcon: function (mimeType) {

			switch (mimeType) {
			case 'Approved':

				return 'Success';
			case 'Rejected':
				return 'Warning';

				// Add more cases for other mime types and their corresponding icons
			default:
				return 'Success';
			}
		},
		onSearch: function (oEvent) {
		
			var aFilter;
			var sQuery = oEvent.getSource().getValue();
			if (sQuery && sQuery.length > 0) {
				aFilter = new sap.ui.model.Filter({
					filters: [
						new Filter("Descrip", sap.ui.model.FilterOperator.Contains, sQuery),
						new Filter("Rigno", sap.ui.model.FilterOperator.EQ, sQuery),
						new Filter("Docno", sap.ui.model.FilterOperator.Contains, sQuery),
					]
				});
			}
			// update list binding
			var InboxList = this.getView().byId("InboxList");
			var binding = InboxList.getBinding("items");
			binding.filter(aFilter);
		},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf E.E.view.Inbox
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf E.E.view.Inbox
		 */
		// onAfterRendering: function () {
		// 	debugger;
		// 	// var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/ZDWO_NX_VENDOR_SRV", true);
		// 	// var sPath = "/InboxSet"
		// 	// oModel.read(sPath, null, null, true, function (success) {
		// 	// 		debugger;
		// 	// 		// var zparse = JSON.parse(oCount);
		// 	// 		var getRecAttchModel = new JSONModel();
		// 	// 		getRecAttchModel.setData(success.results);
		// 	// 		that.getView().setModel(getRecAttchModel, 'getRecAttchModel')

		// 	// 	},
		// 	// 	function (error) {

		// 	// 		MessageBox.error("Data Load Error");
		// 	// 	}
		// 	// );
		// },

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf E.E.view.Inbox
		 */
		//	onExit: function() {
		//
		//	}

	});

});