sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/Popover",
	"sap/m/Button",
	"sap/m/QuickView",
	"sap/m/QuickViewCard",
	"sap/m/Label",
	'sap/ui/core/Fragment',
	"sap/m/Dialog",
	"sap/ui/core/format/DateFormat",
	'sap/m/MessageToast',
	'E/E/model/formatter',
	"sap/m/MessageBox",
	"sap/ui/model/Filter",
], function (Controller, JSONModel, Popover, Button, QuickView, QuickViewCard, Label, Fragment, Dialog, DateFormat, MessageToast,
	formatter, MessageBox, Filter) {
	"use strict";

	return Controller.extend("E.E.controller.Detview", {
		formatter: formatter,
		tableList: [],
		Joblog: [],
		oModel: {},
		comnt: [],
		HeaderToWbsNav: [],
		HeaderToItemsNav: [],
		HeaderToRigNav: [],
		JoblogToPOConsupNav: [],
		vendorObj: {},
		DetailObj: {},
		Files: [],
		FilesJb: [],
		nIndexJB: {},
		detObj: {},
		selectedObj: {},
		jobLoggingitem: [],
		SrvHdrToItemsNav: [],
		JoblogToSerListNav: [],
		jbitempress: "",
		jbtype: "",
		jbselitem: "",
		HeaderToPoNav: [],
		nIndexHdrAtt: {},
		HeaderToCountNav: [],
		daysDifference: {},
		// HeaderProAttch: [],

		onInit: function () {
			this.getOwnerComponent().getRouter().getRoute("Detview").attachMatched(this.onNavToCurrentPage, this);
			var that = this;

		},

		Append: function () {
			this.getView().byId('panelViewedxyz').setExpanded(false);
			this.getView().byId('selectedPan').setExpanded(true);
		},


		onNavToCurrentPage: function (e) {

			var that = this;
			that.getView().getModel('oTableModel').setData(null);
			that.detObj = e.getParameters('arguments').arguments;
			if (that.detObj.Docno !== "" && that.detObj.Mjahr !== "") {
				// that.getView().byId("Jblog").setEnabled(true);
				that.getView().byId("Jblog").setVisible(true);

				that.getView().byId("JobLoggingType").setVisible(true);
				that.getView().byId("jbt").setVisible(true);
				// that.getView().byId("JobPanel").setVisible(false);

				// this.getView().byId("DocNoTxt").setVisible(true);
				// this.getView().byId("DocNo").setVisible(true);
				// 	this.getView().byId("DocNoTxts").setVisible(true);
				// this.getView().byId("DocNo0").setVisible(true);
				// this.getView().byId("Jblog").setEnabled(false);
				// this.getView().byId("createser").setVisible(true);

				var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/ZDWO_NX_VENDOR_SRV", true);

				var Docno = that.detObj.Docno;
				// var Docno = "3000003877";
				var Mjahr = that.detObj.Mjahr;
				var flag = "V"
				var filter1 = new sap.ui.model.Filter('Docno', 'EQ', Docno);
				var filter2 = new sap.ui.model.Filter('Mjahr', 'EQ', Mjahr);
				var filter3 = new sap.ui.model.Filter('LogType', 'EQ', "OPE");
				sap.ui.core.BusyIndicator.show();
				oModel.read("/ServiceHdrSet(Docno='" + Docno + "',Mjahr='" + Mjahr + "',UserFlag='" + flag + "')", {
					urlParameters: {
						"$expand": "SrvHdrToItemsNav,SrvHdrToCommNav,SrvHdrToAttNav"
					},
					success: function (oData, oResponse) {

						that.SrvHdrToItemsNav = oData.SrvHdrToItemsNav.results;
						var SrvHdrToItemsNav = new JSONModel();
						SrvHdrToItemsNav.setData(SrvHdrToItemsNav);
						that.getView().setModel(SrvHdrToItemsNav, 'SrvHdrToItemsNav');

						var attachDet = oData.SrvHdrToAttNav.results;
						var attachModel = new JSONModel();
						attachModel.setData(attachDet);
						that.getView().setModel(attachModel, 'attachModel');
						that.tableList.length = 0;
						var SelectedOne = oData.SrvHdrToItemsNav.results;
						SelectedOne.forEach(function (index) {
							var selectedObjData = {};
							selectedObjData.RefNo = index.Zeile;
							selectedObjData.Description = index.Maktxo;
							selectedObjData.Uom = index.Meins;
							selectedObjData.Qnty = index.Menge;
							that.tableList.push(selectedObjData);
							that.getView().getModel('oTableModel').setData(that.tableList);
						});

						// var SelectedModel = new JSONModel();
						// SelectedModel.setData(that.selectedObj);
						// // that.oView.setModel(Jboperation, 'Jboperation');
						// that.getView().setModel(SelectedModel, 'SelectedModel')
						if (oData.Rqstat === "JOBL") {
							// that.getView().byId("TopVBox1").setVisible(true);
							that.getView().byId("JobPanel").setVisible(true);
							that.getView().byId("Jblog").setEnabled(true);
						} else {
							that.getView().byId("JobPanel").setVisible(false);
							that.getView().byId("Jblog").setEnabled(false);
						}
						that.getView().byId("TopVBox1").setVisible(true);
						that.DetailObj.Docno = oData.Docno;
						that.DetailObj.Ebeln = oData.Ebeln;
						that.DetailObj.Mjahr = oData.Mjahr;
						that.DetailObj.PoConperc =
							oData.PoConperc;

						that.DetailObj.PoTitle = oData.PoTitle;
						that.DetailObj.PoTrgtval = oData.PoTrgtval;
						that.DetailObj.ServiceDesc = oData.ServiceDesc;
						that
							.DetailObj.ServiceId = oData.ServiceId;

						that.DetailObj.SesConsv = oData.SesConsv;
						that.DetailObj.TotalCommit = oData.TotalCommit;
						that.DetailObj.TotalValue = oData.TotalValue;
						that.DetailObj.WsiteDhaGateDis = oData.WsiteDhaGateDis;
						that.DetailObj.Location = oData.RigShrtName;
						that.DetailObj.wbs = oData.KnttpVal;

						that.DetailObj.But1Text = oData.But1Text;
						that.DetailObj.But1Visible = oData.But1Visible;
						that.DetailObj.But2Text = oData.But2Text;
						that.DetailObj.But2Visible = oData.But2Visible;

						that.DetailObj.But3Text = oData.But3Text;
						that.DetailObj.But3Visible = oData.But3Visible;

						that.DetailObj.But4Text = oData.But4Text;
						that.DetailObj.But4Visible = oData.But4Visible;

						// if (that.DetailObj.But4Text === "Delete") {
						// 	that.getView().byId("Delete").setVisible(true);
						// }
						if (that.DetailObj.But2Visible === "false") {
							that.getView().byId("Submit").setVisible(false);
						}
						if (that.DetailObj.But4Visible === "false") {
							that.getView().byId("Delete").setVisible(false);
						}

						var DetailObj = new JSONModel();
						DetailObj.setData(that.DetailObj);
						that.getView().setModel(DetailObj, 'DetailObj');
						that.getView().byId('Remote').setValue(that.DetailObj.Location);
						var getDetailModel = that.getView().getModel('DetailObj');
						that.getView().byId('WBS').setValue(that.DetailObj.wbs);
						sap.ui.core.BusyIndicator.hide();
					},
					error: function (oData, response) {

						MessageBox.success("Data Load Error");
						sap.ui.core.BusyIndicator.hide();

					}
				});
				oModel.read("/JobOpelistSet", {
					filters: [filter1, filter2, filter3],

					success: function (oData, oResponse) {

						that.jobLoggingitem = oData.results;
						var OprsubtItem = [];
						var OpraprItem = [];
						var OprallItem = [];
						var Opractlog = [];
						var OprREJC = [];

						that.jobLoggingitem.forEach((element) => {
							if (element.Status === "SUBT") {
								// var servieitem = {};
								OprsubtItem.push(element);

							} else if (element.Status === "INIT") {
								Opractlog.push(element);

							} else if (element.Status === "APRV") {
								OpraprItem.push(element);

							}
						});

						var OPRsubtItemModel = new JSONModel();
						OPRsubtItemModel.setData(OprsubtItem);
						that.getView().setModel(OPRsubtItemModel, 'OPRsubtItemModel');

						var OPRactlogModel = new JSONModel();
						OPRactlogModel.setData(Opractlog);
						that.getView().setModel(OPRactlogModel, 'OPRactlogModel');

						var OPRaprItemModel = new JSONModel();
						OPRaprItemModel.setData(OpraprItem);
						that.getView().setModel(OPRaprItemModel, 'OPRaprItemModel');

						var Jboperation = new JSONModel();
						Jboperation.setData(that.jobLoggingitem)
						that.getView().setModel(Jboperation, "Jboperation");

						sap.ui.core.BusyIndicator.hide();
					},
					error: function (oData, response) {
						var data = oData.results;
						MessageBox.success("Data Load Error");
						sap.ui.core.BusyIndicator.hide();

					}

				});

				oModel.read("/JobLoggingSet(Docno='" + Docno + "',Mjahr='" + Mjahr + "')", {
					urlParameters: {
						// "$expand": "JoblogToDRSSNav,JoblogToOpeListNav,JoblogToPOConsupNav,JoblogToSerListNav"
						// "$expand": "JoblogOpeListNav,JoblogToDRSSNav,JoblogToAttachNav,JoblogToSerListNav,JoblogToPOConsupNav,,JoblogToTimesheetNav,JoblogToPumpsheetNav"

						"$expand": "JoblogOpeListNav,JoblogToAttachNav,JoblogToDRSSNav,JoblogToPOConsupNav,JoblogToSerListNav,JoblogToTimesheetNav,JoblogToPumpsheetNav"

					},
					success: function (oData, oResponse) {

						that.JoblogToSerListNav = oData.JoblogToSerListNav.results;
						var JoblogToSerListNav = new JSONModel();
						JoblogToSerListNav.setData(that.JoblogToSerListNav);
						that.getView().setModel(JoblogToSerListNav, 'JoblogToSerListNav');
						that.JobLogging.setModel(JoblogToSerListNav, 'JoblogToSerListNav')

						var obj = {
							itemselect: ""
						};
						var DropJB = new JSONModel();
						DropJB.setData(obj);
						that.getView().setModel(DropJB, 'DropJB');

						that.JoblogToPOConsupNav = oData.JoblogToPOConsupNav.results;
						var JoblogToPOConsupNav = new JSONModel();
						JoblogToPOConsupNav.setData(that.JoblogToPOConsupNav);
						that.getView().setModel(JoblogToPOConsupNav, 'JoblogToPOConsupNav');

						that.JoblogToDRSSNav = oData.JoblogToDRSSNav.results;
						var subtItem = [];
						var aprItem = [];
						var allItem = [];
						var actlog = [];
						var REJC = [];

						that.JoblogToDRSSNav.forEach((element) => {
							if (element.Jlstatus === "SUBT") {
								// var servieitem = {};
								subtItem.push(element);

							} else if (element.Jlstatus === "INIT") {
								actlog.push(element);

							} else if (element.Jlstatus === "APRV") {
								aprItem.push(element);

							}
							// else if (element.Jlstatus === "REJC") {
							// 	aprItem.push(element);

							// }
						});
						var subtItemModel = new JSONModel();
						subtItemModel.setData(subtItem);
						that.getView().setModel(subtItemModel, 'subtItemModel');

						var actlogModel = new JSONModel();
						actlogModel.setData(actlog);
						that.getView().setModel(actlogModel, 'actlogModel');

						var aprItemModel = new JSONModel();
						aprItemModel.setData(aprItem);
						that.getView().setModel(aprItemModel, 'aprItemModel');

						var Jbservice = new JSONModel();
						Jbservice.setData(that.JoblogToDRSSNav);
						that.getView().setModel(Jbservice, 'Jbservice');

						that.JoblogOpeListNav = oData.JoblogOpeListNav.results;
						var obj = {
								length: that.JoblogOpeListNav.length
							}
							// that.JoblogOpeListNav.push(obj);
							// var Jboperation = new JSONModel();
							// Jboperation.setData(that.JoblogOpeListNav);
							// that.oView.setModel(Jboperation, 'Jboperation');
							// that.getView().setModel(Jboperation, 'Jboperation')

						that.DetailObj.Docno = oData.Docno;
						that.DetailObj.Ebeln = oData.Ebeln;
						that.DetailObj.Mjahr = oData.Mjahr;
						that.DetailObj.PoConperc = oData.PoConperc;

						that.DetailObj.PoTitle = oData.PoTitle;
						that.DetailObj.PoTrgtval = oData.PoTrgtval;
						that.DetailObj.ServiceDesc = oData.ServiceDesc;
						that.DetailObj.ServiceId = oData.ServiceId;

						that.DetailObj.SesConsv = oData.SesConsv;
						that.DetailObj.TotalCommit = oData.TotalCommit;
						that.DetailObj.TotalValue = oData.TotalValue;
						that.DetailObj.WsiteDhaGateDis = oData.WsiteDhaGateDis;

						var DetailObj = new JSONModel();
						DetailObj.setData(that.DetailObj);
						that.oView.setModel(DetailObj, 'DetailObj')

					},
					error: function (oData, response) {

						var data = oData.results;
						console.log(data);
						MessageBox.success(oData.statusText);

					}
				});

			} else {
				MessageToast.show("Item job logging not found");
			}
		},

		onSearch: function (oEvent) {

			var aFilter;
			var sQuery = oEvent.getSource().getValue();
			if (sQuery && sQuery.length > 0) {
				aFilter = new sap.ui.model.Filter({
					filters: [
						new Filter("PurchOrder", sap.ui.model.FilterOperator.EQ, sQuery),
						new Filter("Description", sap.ui.model.FilterOperator.EQ, sQuery),
						new Filter("Contract", sap.ui.model.FilterOperator.EQ, sQuery),
					]
				});
			}
			// update list binding
			var UPLOAD = this.getView().byId("cardsGrid");
			var binding = UPLOAD.getBinding("items");
			binding.filter(aFilter);
		},
		// onAddJb: function (oEvent) {
		// 	debugger;
		// 	var oTable = this.getView().byId("tableId211");
		// 	// var oModel = this.getView().getModel('FormData');
		// 	// oTable.setModel("oModel");
		// 	oTable.bindAggregation("items", "/items", oItem)

		// 	var oItem = new sap.m.ColumnListItem({
		// 		cells: [
		// 			new sap.m.Input({
		// 				value: "{FormData>BG}"
		// 			}),
		// 			new sap.m.Input(),
		// 			new sap.m.Input(),
		// 			new sap.m.Input(),
		// 			new sap.m.Input(),
		// 			new sap.m.Input(),
		// 			new sap.m.Input(),
		// 			new sap.m.Input(),
		// 			new sap.m.Input(),
		// 			new sap.m.Input(),
		// 			new sap.m.Input(),
		// 			new sap.m.Input(),
		// 			new sap.m.Input()
		// 		]
		// 	});

		// 	var oTable = this.getView().byId("tableId1");
		// 	oTable.bindAggregation("items", "/items", oItem)
		// 	oTable.addItem(oItem);
		// },

		jbt: function (oEvent) {

			var that = this;
			that.jbtype = oEvent.getSource().mProperties.value;
			that.jbselitem = oEvent.getSource().oParent.sId.split('-')[2];
		},

		ProAtt: function () {

			// if (!this.ProFileAttach) {
			// 	this.ProFileAttach = sap.ui.xmlfragment("E.E.fragments.ProFileAttach", this);
			// }

			this.ProFileAttach.open();

		},

		Pro_ok: function () {

			this.ProFileAttach.close();
		},

		ProClose: function () {
			this.ProFileAttach.close();
		},

		// calculateDaysWithDates: function (startDate, endDate) {
		// 	// Convert both dates to milliseconds
		// 	var that = this;

		// 	var start = new Date(startDate);
		// 	var end = new Date(endDate);

		// 	const startMs = startDate.getTime();
		// 	const endMs = endDate.getTime();

		// 	// Calculate the difference in milliseconds
		// 	const differenceMs = endMs - startMs;

		// 	// Convert milliseconds to days
		// 	that.daysDifference = Math.ceil(differenceMs / (1000 * 60 * 60 * 24));

		// 	var result = [];
		// 	result.push({
		// 		date: "ID/Equipment No",
		// 		type: "input"
		// 	});
		// 	// Loop through each day between the start and end dates
		// 	for (var i = 0; i <= that.daysDifference; i++) {
		// 		var currentDate = new Date(start);
		// 		currentDate.setDate(start.getDate() + i);
		// 		var date = currentDate.toISOString().split('T')[0];
		// 		// result.push(date)
		// 		result.push({
		// 			date: currentDate.toISOString().split('T')[0], // Format the date as YYYY-MM-DD
		// 			// difference: currentDate.toISOString().split('T')[0]
		// 			difference: i,
		// 			type: "input",
		// 			value: ""
		// 		});
		// 	}
		// 	result.push({
		// 		date: "Reference Id",
		// 		type: "input"
		// 	}, {
		// 		date: "",
		// 		type: "button",
		// 		icon: "sap-icon://appear-offline",
		// 		state: "Success"
		// 	}, {
		// 		date: "",
		// 		type: "button",
		// 		icon: "sap-icon://delete",
		// 		state: "Negative"
		// 	});

		// 	return result;

		// 	// return that.daysDifference;
		// },
		// TimeSheetBtn: function () {
		// 	debugger;
		// 	var that = this;
		// 	const startDate = new Date('2024-05-01');
		// 	const endDate = new Date('2024-05-10');
		// 	var datesWithDifference = this.calculateDaysWithDates(startDate, endDate);
		// 	console.log("Days between:", datesWithDifference);
		// 	var Dynamictab = new JSONModel(datesWithDifference);
		// 	that.timeSheet.setModel(Dynamictab, 'Dynamictab')
		// 	that.getView().setModel('Dynamictab');
		// 	var oTable = sap.ui.getCore().byId("idMyTable");
		// 	oTable.setModel(Dynamictab, 'Dynamictab');
		// 	var s = that.daysDifference;

		// 	// Clear existing columns if any
		// 	oTable.removeAllColumns();

		// 	// Get the properties of the model
		// 	var properties = Dynamictab.oData; // Assuming all rows have the same properties

		// 	// Create columns dynamically for each property
		// 	properties.forEach(function (item) {
		// 		var oColumn = new sap.m.Column({
		// 			header: new sap.m.Label({
		// 				text: item.date // Use the property name as the column header
		// 			})
		// 		});
		// 		oTable.addColumn(oColumn);

		// 	})

		// 	var oColumnList = new sap.m.ColumnListItem();

		// 	properties.forEach(function (cell) {
		// 		switch (cell.type) {
		// 		case "input":
		// 			oColumnList.addCell(new sap.m.Input({
		// 				// value: "Dynamictab>/value",
		// 				path: "Dynamictab>/value"
		// 			}));
		// 			break;
		// 		case "button":
		// 			oColumnList.addCell(new sap.m.Button({
		// 				text: cell.text,
		// 				icon: cell.icon,
		// 				type: cell.state,
		// 				press: function (oEvent) {
		// 					// Handle button press event
		// 				}
		// 			}));
		// 			break;
		// 			// Add more cases for other types of cells
		// 		}
		// 	});

		// 	// Add the row to the column list
		// 	// oColumnList.placeAt("content");
		// 	oTable.addItem(oColumnList);
		// 	// oTable.bindRows("/items");

		// 	// oTable.bindItems({
		// 	// 	path: 'Dynamictab>/',
		// 	// 	template: new sap.m.ColumnListItem({
		// 	// 		cells: [
		// 	// 			new sap.m.Text({
		// 	// 				text: "{Dynamictab>date}"
		// 	// 			})
		// 	// 		]
		// 	// 	})
		// 	// });
		// 	that.timeSheet.open();
		// 	////////////////////////////////////////////////////////////////
		// 	// 	var oTable = sap.ui.getCore().byId("idTimesheetTable");
		// 	// oTable.destroyColumns();
		// 	// var oCell = [];
		// 	// var param1 = "TimesheetModels>Id";
		// 	// var param2 = "TimesheetModels>IdGroup";

		// 	// // var oJoblogId = this.getView().getModel("JobLogPopUpModel").getData().JobLog;

		// 	// if('JL0001' === 'JL0001' || 'JL0008' === 'JL0008'  ){
		// 	// 	var oColumn = new sap.m.Column({
		// 	// 		width: "5rem",
		// 	// 		header: new sap.m.Label({
		// 	// 		text: "ID / Equipment No."
		// 	// 		})
		// 	// 	});
		// 	// 	oTable.addColumn(oColumn);

		// 	// 	var cell1 = new sap.m.Input({value: "{TimesheetModels>Id}" , editable: {
		// 	// 		parts:[
		// 	// 			{ path: param1 },
		// 	// 			{ path: param2 }
		// 	// 		],
		// 	// 	formatter: this.editableFlag
		// 	// 	}, maxLength: 10, change:this.TimesheetIdChange , visible: "{= (${TimesheetModels>Id} !== '9999999999')}"});
		// 	// 	oCell.push(cell1);

		// 	// }else{

		// 	// 	var oColumn = new sap.m.Column({
		// 	// 		width: "5rem",
		// 	// 		header: new sap.m.Label({
		// 	// 		text: "ID / Equipment No."
		// 	// 		})
		// 	// 	});
		// 	// 	oTable.addColumn(oColumn);

		// 	// 	var cell1 = new sap.m.Input({value: "{TimesheetModels>Id}", editable: {
		// 	// 		parts:[
		// 	// 			{ path: param1 },
		// 	// 			{ path: param2 }
		// 	// 		],
		// 	// 	formatter: this.editableFlag
		// 	// 	},  maxLength: 10 , change:this.TimesheetIdChange , visible: "{= (${TimesheetModels>Id} !== '9999999999')}"});
		// 	// 	oCell.push(cell1);

		// 	// 	var oColumn = new sap.m.Column({
		// 	// 		width: "10rem",
		// 	// 		header: new sap.m.Label({
		// 	// 		text: "Name / Equipment Desc"
		// 	// 		})
		// 	// 	});
		// 	// 	oTable.addColumn(oColumn);

		// 	// 	var cell1 = new sap.m.Input({value: "{TimesheetModels>Name}", maxLength: 50 , visible: "{= (${TimesheetModels>Id} !== '9999999999')}"});
		// 	// 	oCell.push(cell1);

		// 	// 	var oColumn = new sap.m.Column({
		// 	// 		width: "10rem",
		// 	// 		header: new sap.m.Label({
		// 	// 		text: "Job Title"
		// 	// 		})
		// 	// 	});
		// 	// 	oTable.addColumn(oColumn); 

		// 	// 	var cell1 = new sap.m.Input({value: "{TimesheetModels>JobTitle}", maxLength: 50, editable: "{= (${TimesheetModels>Id} !== '9999999999')}"});
		// 	// 	oCell.push(cell1);
		// 	// }

		// 	// for(var j=0;j<ColoumnUniqueArray.length;j++){

		// 	// 	var ColoumnName = (ColoumnUniqueArray[j].ColName).replaceAll("Jan'","01/").replaceAll("Feb'","02/").replaceAll("Mar'","03/").replaceAll("Apr'","04/").replaceAll("May'","05/").replaceAll("Jun'","06/").replaceAll("Jul'","07/").replaceAll("Aug'","08/").replaceAll("Sept'","09/").replaceAll("Oct'","10/").replaceAll("Nov'","11/").replaceAll("Dec'","12/")

		// 	// 	oColumn = new sap.m.Column({
		// 	// 		width: "4rem",
		// 	// 		header: new sap.m.Label({
		// 	// 		text: ColoumnName
		// 	// 		})
		// 	// 	});
		// 	// 	oTable.addColumn(oColumn);

		// 	// 	cell1 = new sap.m.Input({value: "{TimesheetModels>"+ColoumnUniqueArray[j].ColName+"}",
		// 	// 							type: sap.m.InputType.Number,
		// 	// 							change:function(oEvent){
		// 	// 								if(parseFloat(oEvent.getParameter("newValue")) > -1){

		// 	// 								}else{
		// 	// 									sap.m.MessageBox.error("Please enter a valid value");
		// 	// 									sap.ui.getCore().byId(oEvent.getParameter("id")).setValue("0.00");
		// 	// 								}
		// 	// 								  },
		// 	// 							maxLength: 5});
		// 	// 	oCell.push(cell1);

		// 	// }

		// 	// var oColumn = new sap.m.Column({
		// 	// 	width: "5rem",
		// 	// 	header: new sap.m.Label({
		// 	// 	text: "Reference ID"
		// 	// 	})
		// 	// });
		// 	// oTable.addColumn(oColumn);

		// 	// var cell1 = new sap.m.Text({text: "{TimesheetModels>IdGroup}", visible: "{= (${TimesheetModels>Id}) !== (${TimesheetModels>IdGroup})}"});
		// 	// oCell.push(cell1);

		// 	// var param1 = "TimesheetModels>Id";
		// 	// var param2 = "TimesheetModels>IdGroup";

		// 	// var oColumn = new sap.m.Column({
		// 	// 	width: "2rem",
		// 	// 	header: new sap.m.Label({
		// 	// 	text: ""
		// 	// 	})
		// 	// });
		// 	// oTable.addColumn(oColumn);

		// 	// var cell1 = new sap.m.Button({icon:"sap-icon://citizen-connect",type:"Emphasized" , tooltip:"Add Replacement", 
		// 	// 	visible: {
		// 	// 		parts:[
		// 	// 			{ path: param1 },
		// 	// 			{ path: param2 }
		// 	// 		],
		// 	// 	formatter: this.editableFlagReplacement
		// 	// 	},
		// 	// 	press: function(oEvent) {
		// 	// 	var oRecord = oEvent.getSource().getBindingContext('TimesheetModels').getObject();
		// 	// 	if(oRecord.Id === ""){
		// 	// 		sap.m.MessageBox.error("Please enter ID to proceed with Replacement");
		// 	// 		return;
		// 	// 	}	
		// 	// 	this.TimesheetPath = oEvent.getSource().getBindingContext('TimesheetModels');
		// 	// 	controller.TimesheetPath = oEvent.getSource().getBindingContext('TimesheetModels');

		// 	// 	this.oRecord = oRecord.Id;
		// 	// 	controller.oRecord = oRecord.Id;
		// 	// 	this.onTimesheetConformation();
		// 	//   }.bind(this)});
		// 	// oCell.push(cell1);

		// 	// var aColList = new sap.m.ColumnListItem({
		// 	//        cells: oCell
		// 	//     });

		// 	// var oColumn = new sap.m.Column({
		// 	// 	width: "3rem",
		// 	// 	header: new sap.m.Label({
		// 	// 	text: ""
		// 	// 	})
		// 	// });
		// 	// oTable.addColumn(oColumn);

		// 	// var cell1 = new sap.m.Button({icon:"sap-icon://delete",type:"Reject" , visible: "{= (${TimesheetModels>Id} !== '9999999999')}" ,press: function(oEvent) {
		// 	// 	var oRecord = oEvent.getSource().getBindingContext('TimesheetModels').getObject();
		// 	// 	controller.oData = oEvent.getSource().getModel("TimesheetModels");
		// 	// 	//var oData = controller.getView().getModel("TimesheetModels").getObject("/");
		// 	// 		MessageBox.information("This Timesheet item will be deleted. Do you want to continue ?", {
		// 	// 			actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
		// 	// 			styleClass: "sapUiSizeCompact",
		// 	// 			onClose: function (sAction) {
		// 	// 				if (sAction === "YES") {	
		// 	// 					var oData = controller.oData.getData();
		// 	// 					for (var i = 0; i < oData.length; i++) {
		// 	// 						if (oData[i] == oRecord) {
		// 	// 							oData.splice(i, 1);				
		// 	// 							controller.oData.refresh();
		// 	// 							break;
		// 	// 						}
		// 	// 					}								
		// 	// 					var oTimesheetCount = 0;
		// 	// 					for (var i = 0; i < oData.length; i++) {
		// 	// 						if(oRecord.IdGroup === oData[i].IdGroup){
		// 	// 							oTimesheetCount += parseInt(1)
		// 	// 						}
		// 	// 					}
		// 	// 					if(oTimesheetCount === 1){
		// 	// 						for (var i = 0; i < oData.length; i++) {
		// 	// 							if(oRecord.IdGroup === oData[i].IdGroup){
		// 	// 								oData[i].IdGroup = "";
		// 	// 							}
		// 	// 						}
		// 	// 					}
		// 	// 					controller.oData.refresh();
		// 	// 				}
		// 	// 			}.bind(this)
		// 	// 		});
		// 	//   }});
		// 	// oCell.push(cell1);

		// 	// var aColList = new sap.m.ColumnListItem({
		// 	//        cells: oCell
		// 	//     });

		// 	// oTable.bindAggregation("items", {
		// 	// 	path: "TimesheetModels>/",
		// 	// 	template: aColList
		// 	// });

		// 	// var oTableItems = this.getView().getModel("TimesheetModels").getData();
		// 	// oTableItems.sort(function(a, b){return a.Id- b.Id});
		// 	// this.getView().getModel("TimesheetModels").refresh(true);
		// },
		timeLogSve: function () {

			var that = this
			that.timeSheet.close();
		},

		timeLogClose: function () {
			this.timeSheet.close();
		},

		HdrClose: function () {

			this.ProFileAttach.close();
		},

		ActionLogSubmit: function () {

			var that = this;
			var jbservicearaay = [];
			const aSelItems = this.getView().byId("JbService").getSelectedItems();
			aSelItems.forEach(oItem => {
				var seljbservie = {};
				var oindex = oItem.sId.split('-')[4]
				var getSelected = that.getView().getModel('actlogModel').getData()[oindex];
				seljbservie.Docno = getSelected.Docno,
					seljbservie.Mjahr = getSelected.Mjahr,
					seljbservie.Zeile = getSelected.Zeile,
					seljbservie.JobId = getSelected.JobId,
					seljbservie.Sno = getSelected.Sno,
					seljbservie.JobLog = getSelected.JobLog,
					seljbservie.JobLogDesc = getSelected.JobLogDesc,
					seljbservie.VendorAdd = "X",
					seljbservie.Jlstatus = "SUBT",
					seljbservie.Unit = getSelected.Unit,
					seljbservie.Currency = getSelected.Currency,
					seljbservie.UnitPrice = getSelected.UnitPrice,
					seljbservie.QtyVol = getSelected.QtyVol,
					seljbservie.StartDate = getSelected.MrDate,
					seljbservie.EndDate = getSelected.MrEndDate,
					seljbservie.StartTime = getSelected.StartTime,
					seljbservie.EndTime = getSelected.EndTime,
					jbservicearaay.push(seljbservie)

			});
			// var obj = {
			// 	"Docno": that.detObj.Docno,
			// 	"Mjahr": that.detObj.Mjahr,
			// 	"LogType": "OPE",
			// 	"NotifCode": "SUBT",
			// 	"JoblogOpeNav": selectedObj

			// };
			var obj = {
				"Docno": that.detObj.Docno,
				"Mjahr": that.detObj.Mjahr,
				"Version": "0000",
				"ServiceId": "DPDS",
				"ServiceDesc": "Directional & Performance Drilling Services",
				"Currency": "SAR",
				"TotalValue": "0.00",
				"GrossValue": "0.00",
				"FormCode": "F019",
				"NotifCode": "SUBT",
				"JoblogToDRSSNav": jbservicearaay,
				"JoblogToAttachNav": that.FilesJb
			}

			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/ZDWO_NX_VENDOR_SRV", true);
			oModel.create("/JobLoggingSet ", obj, {
				success: function (oData, oResponse) {

					MessageBox.success("Service Request '" + oData.Docno + "' Generated");
					sap.ui.core.BusyIndicator.hide();
				},
				error: function (oError) {
					MessageBox.success("Service Request is not created");
					sap.ui.core.BusyIndicator.hide();
				}
			});

		},

		ProAttch: function () {;

			// var that = this;
			var HdrProObJ = {
				"Header": "Other Files",
				"Valid_till": "",
				"Valid_from": ""

			}
			var getDATA = sap.ui.getCore().byId("ProAttchments").getModel("oProModel").getData()
			getDATA.push(HdrProObJ);
			sap.ui.getCore().byId("ProAttchments").getModel("oProModel").setData(getDATA);
			// sap.ui.getCore().byId("ProAttchments").getModel("oProModel").refresh();
			// sap.ui.getCore().byId("ProAttchments").setModel(oProModel, "oProModel");
			// // var oTable = sap.ui.getCore().byId("ProAttchments");
			// // var btn = that.getView().byId('CrdBtn');
			// // var spath = oEvent.getSource().getBindingContext();
			// // var oIndex = oEvent.getSource().getBindingContext().sPath.split("/")[2]
			// // var oModel = that.getView().getModel();
			// // var getData = oModel.getData().cards[oIndex];

			// // that.HeaderProAttch.push(HdrProObJ);
			// var oProModel = new JSONModel(HdrProObJ);
			// sap.ui.getCore().byId("ProAttchments").setModel(oProModel, "oProModel");

			// var oItem = new sap.m.ColumnListItem({
			// 	cells: [
			// 		new sap.m.Input(),
			// 		new sap.m.Input(),
			// 		new sap.m.Input(),
			// 		new sap.m.Input({
			// 			showValueHelp: true

			// 		}),
			// 	]
			// });

			// var oTable = sap.ui.getCore().byId("ProAttchments");
			// oTable.addItem(oItem);
		},

		HdritemAdd: function () {

			// var oItem = new sap.m.ColumnListItem({
			// 	cells: [
			// 		new sap.ui.unified.FileUploader({
			// 			buttonOnly: true,
			// 			buttonText: " ",
			// 			icon: "sap-icon://attachment",
			// 			change: [this.attachment, this]
			// 		}),
			// 		new sap.m.Input(),
			// 		new sap.m.Label(),
			// 		new sap.m.Label(),
			// 		new sap.m.Button({
			// 			icon: "sap-icon://delete",
			// 			type: "Negative",
			// 			press: [this.deleteRow2, this]
			// 		}),

			// 	]
			// });

			// var oTable = sap.ui.getCore().byId("HdrAttchments");
			// oTable.addItem(oItem);
			//  //oTable.setProperty("HdrFile>/");

			var HdrFile = {
				"File": "",
				"FileValue": "",
				"Filename": "",
				"MIMEType": "",
				"Docno": "",
				"Year": "",

			}
			var getDATA1 = sap.ui.getCore().byId("HdrAttchments").getModel("HdrFile").getData()
			getDATA1.push(HdrFile);
			sap.ui.getCore().byId("HdrAttchments").getModel("HdrFile").setData(getDATA1);
		},

		Hdr_ok: function () {

		},
		HdrClose: function () {
			this.HdrAtt.close();
		},
		Hdrok: function () {

			var that = this;
			sap.ui.getCore().byId("HdrAttchments").getModel("HdrFile");

			this.HdrAtt.close();
		},

		onPress: function (oEvent) {

			var getData = this.getView().getModel('oTableModel').getData();
			var indexes = oEvent.getSource().sId.split('-')[2];
			var dtset = getData[indexes];
			var obj = {
				Contract: "",
				Curr: "",
				Description: dtset.Description,
				GrossPrice: "",
				Material: "",
				PurchLine: "",
				PurchOrder: "",
				Qnty: "",
				RefNo: dtset.RefNo,
				ServType: "",
				Status: "",
				UnitPrice: "",
				Uom: dtset.Uom,
				VendorID: "",
				Depth_From: "",
				Depth_To: "",
				Depth: "",
				Footage: "",
				Quantity: "",
				UOM: "",
				Unit_Price: "",
				Gross_Price: "",
				Net_Price: "",
				Comment: "",
				StrtDate: "",
				Strt_tim: "",
				EndDate: "",
				End_tim: "",
				TVD_beg: "",
				ht_fac: ""

			}
			var JBModel = new JSONModel(obj);
			this.getView().setModel(JBModel, "JBModel");
			this.JobLogging.setModel(JBModel, "JBModel");
			if (!this.JobLogging) {
				this.JobLogging = sap.ui.xmlfragment("E.E.fragments.JobLogging", this);
				var JBModel = new JSONModel(obj);
				this.JobLogging.setModel(JBModel, "JBModel");
			}
			var JBModel = new JSONModel(obj);
			this.JobLogging.setModel(JBModel, "JBModel");
			this.JobLogging.open();
			this.getView().getModel("JBModel").refresh(true);

		},
		// onPressCancelHrd: function () {
		// 	debugger

		// 	this.ProFileAttach.close();
		// },
		handleCoPilotClick: function (oEvent) {

			var demoToast = this.getView().byId("demoToast");
			demoToast.setText("Event coPilotClick fired.");
			demoToast.show();
		},
		eticketPre: function () {

			var that = this;
			that.EticketPreview.open();
		},

		submit: function (oEvent) {
			debugger;
			var that = this;
			var btntext = this.getView().byId('Submit').getText();
			if (btntext === "Release Job") {
				that.eticketPre();
			} else {
				var getHdrAttch = sap.ui.getCore().byId("HdrAttchments").getModel("HdrFile").getData();
				var Rqstat = "";
				if (that.detObj.Docno === undefined || that.detObj.Mjahr === undefined) {

					that.detObj.Docno = "";
					that.detObj.Mjahr = "";
				}
				var btntext = this.getView().byId('Submit').getText();
				if (btntext === "Start Job") {
					Rqstat = "JOBL"
				} else if (btntext === "Recall") {
					Rqstat = "RECL"
				} else if (btntext === "Ready to do Job") {
					Rqstat = "SUBT"
				}

				// if (this.getView().byId('JobPanel').getVisible() === "false") {

				var selseraraay = [];
				var selserv = that.getView().getModel('oTableModel').getData();
				if (selserv.length > 0) {
					selserv.forEach(function (oindex) {
						var selservie = {};
						selservie.PoNo = oindex.PurchOrder;
						selservie.PoItem = oindex.PurchLine;
						selservie.Menge = oindex.Qnty;
						selservie.Meins = oindex.Uom;
						selservie.RefNo = oindex.ContRef;
						selservie.Matnr = oindex.Material;
						selservie.Maktxo = oindex.Description;
						selservie.GrPrice = oindex.GrossPrice;
						selservie.Curr = oindex.Curr;
						selservie.LineNo = oindex.LineNo;
						selservie.Matnr = oindex.Material;
						selservie.PckgNo = oindex.PckgNo;
						selseraraay.push(selservie)
					});

					var Lifnr;
					var RigShrtName = that.getView().byId('Remote').getValue();
					var Rigno = that.getView().byId('Remote').mProperties.selectedKey
					var wbs = that.getView().byId('WBS').getValue();
					var Prrty = that.getView().byId('Priority').getSelectedKey();
					var Rqddt = that.getView().byId('TobeComp').getValue();
					// var dateFormat = DateFormat.getDateInstance({
					// 	pattern: "yyyy-MM-dd"
					// });
					// var Rqddts = dateFormat.format(new Date(Tobecomplete));

					// var Rqddt = Rqddts.replace("-", "", ""); // Output: "ello World!"
					var remarks = this.cumBix.getModel('remObj').getData().Remarks;
					var hdrCmntArr = [];
					var hdrCmntStr = {
						Text: remarks
					};
					hdrCmntArr.push(hdrCmntStr);
					that.HeaderToRigNav.forEach(function (oIndex) {

						if (Rigno === oIndex.RigCode) {
							that.Lifnr = oIndex.VendorID;
						} else {
							console.log('Vendor Not Found')
						}
					});
					var obj = {
						"Docno": that.detObj.Docno,
						"Mjahr": that.detObj.Mjahr,
						"Rqddt": Rqddt, //"20240411",
						"Lifnr": that.Lifnr,
						"Wellnm": that.vendorObj.WellName, //-------------that.vendorObj.WellName-----	that.vendorObj.WellName
						"Rigno": Rigno,
						"RigShrtName": RigShrtName,
						"Knttp": "P",
						"KnttpVal": wbs, //---wbs
						"Rqstat": Rqstat,
						"Prrty": Prrty,
						"Konnr": "6600003759",
						"SrvHdrToItemsNav": selseraraay,
						"SrvHdrToItmAttNav": that.Files,
						"SrvHdrToCommNav": hdrCmntArr,
						"SrvHdrToAttNav": getHdrAttch //srvhdrtoattachnav
					}
					sap.ui.core.BusyIndicator.show();
					var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/ZDWO_NX_VENDOR_SRV", true);
					oModel.create("/ServiceHdrSet", obj, {
						success: function (oData, oResponse) {

							if (oData.Rqstat === "SUBT") {
								MessageBox.success("Service Request '" + oData.Docno + "' Submitted");
							} else if (oData.Rqstat === "JOBL") {
								MessageBox.success("Service Request '" + oData.Docno + "' Ready to Job Log");
							} else if (oData.Rqstat === "RECL") {
								MessageBox.success("Service Request '" + oData.Docno + "' Recall successfully");
							}
							that.getView().byId('Remote').setValue(null);
							that.getView().byId('WBS').setValue(null);
							that.getView().getModel('Count').setData(null);
							that.getView().getModel('oTableModel').setData(null);
							sap.ui.core.BusyIndicator.hide();
						},
						error: function (oError) {
							MessageBox.success("Service Request is not created");
							sap.ui.core.BusyIndicator.hide();
						}
					});
				} else {

					MessageToast.show("Selected service note found");
				}
			}
		},

		JBsubmit: function (oEvent) {

			var that = this;
			var Lifnr;
			var jbdata = that.getView().getModel('Jboperation').getData();
			var RigShrtName = that.getView().byId('Remote').getValue();
			var Rigno = that.getView().byId('Remote').mProperties.selectedKey
			var wbs = that.getView().byId('WBS').getValue();

			var oitem = that.getView().byId('ALItem').getSelectedItem();
			const aSelItems = this.getView().byId("ALItem").getSelectedItems();
			var selectedpathindex = this.getView().byId("ALItem")._aSelectedPaths[0].split('/')[1];
			const oSharedModel = this.getView().getModel('Jboperation').getData();
			var selectedObj = [];

			aSelItems.forEach(oItem => {
				var selservie = {};
				var oindex = oItem.sId.split('-')[4]
				var getSelected = this.getView().getModel('Jboperation').getData()[oindex];
				selservie.Docno = getSelected.Docno,
					selservie.Mjahr = getSelected.Mjahr,
					selservie.LogType = "OPE",
					selservie.Created = "X",
					selservie.Seqno = getSelected.Seqno,
					selservie.CatCode = getSelected.CatCode,
					selservie.FrDate = "20240403",
					selservie.FrTime = "130000",
					selservie.Status = "SUBT",
					selservie.FormCode = getSelected.FormCode,
					selservie.Copy = getSelected.Copy,
					selservie.StatusText = "Draft"
				selectedObj.push(selservie)

			});

			// var JBItems = [];

			// jbdata.forEach(function (oindex) {
			// 	var JBObj = {};
			// 	JBObj.Docno = oindex.Docno;
			// 	JBObj.Mjahr = oindex.Mjahr;
			// 	JBObj.LogType = oindex.LogType;
			// 	JBObj.Created = "X";
			// 	JBObj.Seqno = oindex.Seqno;
			// 	JBObj.CatCode = oindex.CatCode;
			// 	JBObj.FrDate = oindex.FrDate;
			// 	JBObj.FrTime = oindex.FrTime;
			// 	JBObj.Status = oindex.Status;
			// 	JBObj.FormCode = oindex.FormCode;
			// 	JBObj.Copy = oindex.Copy;
			// 	JBObj.StatusText = "Draft";
			// 	JBItems.push(JBObj)
			// });

			var obj = {
				"Docno": that.detObj.Docno,
				"Mjahr": that.detObj.Mjahr,
				"LogType": "OPE",
				"NotifCode": "SUBT",
				"JoblogOpeNav": selectedObj

			};
			sap.ui.core.BusyIndicator.show();
			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/ZDWO_NX_VENDOR_SRV", true);
			oModel.create("/JobOpelistSet ", obj, {
				success: function (oData, oResponse) {

					MessageBox.success("Service Request '" + oData.Docno + "' Generated");
					sap.ui.core.BusyIndicator.hide();
					// that.getView().byId('Remote').setValue(null);
					// that.getView().byId('WBS').setValue(null);
					// that.getView().getModel('Count').setData(null);
					// that.getView().getModel('oTableModel').setData(null);
					// sap.ui.core.BusyIndicator.hide();
				},
				error: function (oError) {
					MessageBox.success("Service Request is not created");
					sap.ui.core.BusyIndicator.hide();
				}
			});

		},

		Draft: function (oEvent) {

			var that = this;
			var Rqstat = "";
			if (that.detObj.Docno === undefined || that.detObj.Mjahr === undefined) {

				that.detObj.Docno = "";
				that.detObj.Mjahr = "";
			}
			var btntext = this.getView().byId('draft').getText();
			if (btntext === "Start Job") {
				Rqstat = "JOBL"
			} else if (btntext === "Recall") {
				Rqstat = "RECL"
			} else if (btntext === "Save as Draft") {
				Rqstat = "VINT"
			}

			var selseraraay = [];
			var selserv = that.getView().getModel('oTableModel').getData();
			if (selserv.length > 0) {
				selserv.forEach(function (oindex) {
					var selservie = {};
					selservie.PoNo = oindex.PurchOrder;
					selservie.PoItem = oindex.PurchLine;
					selservie.Menge = oindex.Qnty;
					selservie.Meins = oindex.Uom;
					selservie.RefNo = oindex.ContRef;
					selservie.Matnr = oindex.Material;
					selservie.Maktxo = oindex.Description;
					selservie.GrPrice = oindex.GrossPrice;
					selservie.Curr = oindex.Curr;
					selservie.LineNo = oindex.LineNo;
					selservie.Matnr = oindex.Material;
					selservie.PckgNo = oindex.PckgNo;

					selseraraay.push(selservie)
				});
			} else {
				var selservie = {};
				selseraraay.push(selservie);
			}
			var Lifnr;
			var RigShrtName = that.getView().byId('Remote').getValue();
			var Rigno = that.getView().byId('Remote').mProperties.selectedKey
			var wbs = that.getView().byId('WBS').getValue();
			var obj = {
				"Docno": that.detObj.Docno,
				"Mjahr": that.detObj.Mjahr,
				"Rqddt": "20240411",
				"Lifnr": that.Lifnr,
				"Wellnm": that.vendorObj.WellName, //-------------that.vendorObj.WellName-----	that.vendorObj.WellName
				"Rigno": Rigno,
				"RigShrtName": RigShrtName,
				"Knttp": "P",
				"KnttpVal": wbs, //---wbs
				"Rqstat": Rqstat,
				"Konnr": "6600003759", // ----------
				"SrvHdrToItemsNav": selseraraay,
				"SrvHdrToCommNav": [{}],
				"SrvHdrToAttNav": that.Files //srvhdrtoattachnav
			}
			sap.ui.core.BusyIndicator.show();
			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/ZDWO_NX_VENDOR_SRV", true);
			oModel.create("/ServiceHdrSet", obj, {
				success: function (oData, oResponse) {
					if (oData.Rqstat === "VINT") {
						MessageBox.success("Service Request '" + oData.Docno + "' is save to Draft");
					} else if (oData.Rqstat === "JOBL") {
						MessageBox.success("Service Request '" + oData.Docno + "' Ready to Job Log");
					} else if (oData.Rqstat === "RECL") {
						MessageBox.success("Service Request '" + oData.Docno + "' Recall successfully");
					}

					// MessageBox.success("Service Request " + oData.Docno + " Generated ");
					that.getView().byId('Remote').setValue(null);
					that.getView().byId('WBS').setValue(null);
					// that.getView().getModel('Count').setData(null);
					that.getView().getModel('oTableModel').setData(null);
					sap.ui.core.BusyIndicator.hide();

				},
				error: function (oError) {

					MessageBox.success("Service Request is not created");
					sap.ui.core.BusyIndicator.hide();

				}
			});

		},
		// Draft2: function (oEvent) {
		// 	debugger;
		// 	var obj = {
		// 			RQSTAT: "SUBT"
		// 		}
		// 		//var RQSTAT = "INIT"
		// 	var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/ZDWO_NX_VENDOR_SRV", true);
		// 	oModel.create("/ServiceHdrSet", obj, {
		// 		success: function (oData, oResponse) {

		// 			debugger;
		// 		},
		// 		error: function (oError) {
		// 			debugger;

		// 		}
		// 	});

		// },
		// capturePhoto2: function () {
		// 	
		// 	var busyAL = {
		// 		busy: true
		// 	};
		// 	// var oJsonModel = new JSONModel(busyAL);
		// 	// this.mainView.setModel(oJsonModel, "busyIC");
		// 	var that = this;
		// 	// if (this.cameraDialog) {
		// 	// 	this.mainView.removeDependent(this.cameraDialog);
		// 	// 	this.cameraDialog.destroy();
		// 	// }
		// 	this.cameraDialog = new Dialog({
		// 		busy: "{busyIC>/busy}",
		// 		title: "Click on Capture to take a photo",
		// 		beginButton: new Button({
		// 			text: "Capture",
		// 			press: function (oEvent) {
		// 				//onsubmit
		// 				var cont = document.getElementById("idImageCanvas");
		// 				var vid = document.getElementById("idImageCap3");
		// 				cont.width = 768;
		// 				cont.height = 512;
		// 				cont.getContext("2d").drawImage(vid, 0, 0, cont.width, cont.height)
		// 				var base64STR = cont.toDataURL("image/png");
		// 				vid.pause();
		// 				vid.srcObject.getTracks()[0].stop();
		// 				//vid.srcObject = "";
		// 				that.cameraDialog.close()
		// 				that.imageData = base64STR;
		// 				that.postNote("IMG")
		// 			}

		// 		}),
		// 		endButton: new Button({
		// 			text: "Cancel",
		// 			press: function () {
		// 				var vid = document.getElementById("idImageCap3");
		// 				vid.pause();
		// 				vid.srcObject.getTracks()[0].stop();
		// 				that.cameraDialog.close()
		// 			}
		// 		}),
		// 		content: [new sap.ui.core.HTML({
		// 				content: '<video id="idImageCap3" autoplay></video>'
		// 			}),
		// 			new sap.ui.core.HTML({
		// 				content: '<canvas id="idImageCanvas" width="1px" height="1px"></canvas>',
		// 			})
		// 		]
		// 	})

		// 	// this.mainView.addDependent(this.cameraDialog);
		// 	this.cameraDialog.open();
		// 	navigator.mediaDevices.getUserMedia({
		// 		video: true
		// 	}).then(function (stream) {
		// 		var player22 = document.getElementById("idImageCap3");
		// 		player22.srcObject = stream;
		// 		that.mainView.getModel("busyIC").setProperty("/busy", false);

		// 	})

		// },

		// uploadPic: function (oEvent) {
		// 	
		// 	//			  busyIndicator.setProperty("/busy", true);
		// 	var reader = new FileReader();
		// 	var that = this;
		// 	reader.onload = function (e) {
		// 		that.imageData = e.currentTarget.result;
		// 		that.postNote("IMG")
		// 	}
		// 	reader.readAsDataURL(oEvent.getParameters().files[0]);
		// 	//			  busyIndicator.setProperty("/busy", false);
		// },
		// onCancelNotes: function(){

		// },

		XYZ: function (oEvent) {

			this.getView().byId('WBS').setValue(null);
			var array = [];
			// var obj = {};
			var key = oEvent.getSource().getProperty('selectedKey');
			this.HeaderToWbsNav.forEach(function (oIndex) {
				var obj = {};
				if (key === oIndex.RigCode) {
					obj.RigCode = oIndex.RigCode;
					obj.Wbs = oIndex.Wbs;
					array.push(obj);

				} else {
					console.log('no WBS against this Remote Location')
				}

			});

			var OModel = new JSONModel();
			OModel.setData(array);
			this.getView().setModel(OModel, 'WbsModel')

		},

		poSelected: function (oEvent) {

			var that = this;

			// this.getView().byId('WBS').setValue(null);
			var array = [];
			// var obj = {};
			var key = oEvent.getSource().getProperty('selectedKey');
			that.HeaderToItemsNav.forEach(function (oIndex) {

				if (key === oIndex.PurchOrder) {
					array.push(oIndex);

				} else {
					console.log('Service not found')
				}
			});
			var HeaderToItemsNav = new JSONModel();

			HeaderToItemsNav.setData({
				"cards": array
			});
			that.getView().setModel(HeaderToItemsNav, 'HeaderToItemsNav');

		},

		onPost: function (oEvent) {

			var that = this;
			var oFormat = DateFormat.getDateTimeInstance({
				style: "medium"
			});
			var oDate = new Date();
			var sDate = oFormat.format(oDate);
			// create new entry
			var sValue = sap.ui.getCore().byId("idInputContent").getValue();
			var oEntry = {
				Author: "SY_UNAME",
				Type: "Reply",
				Date: "" + sDate,
				Text: sValue
			};

			// update model
			// var array = []
			// var oModel = new JSONModel();
			var oModel = this.getView().getModel("ChatObj");
			// 	var aEntries = array;
			that.comnt.unshift(oEntry);
			oModel.setData(that.comnt);
			this.cBux.setModel(oModel, "ChatObj")
			this.getView().getModel("ChatObj").refresh;
			// this.getView().setModel(oModel);
			// var aEntries = array;
			// array.unshift(oEntry);
			// oModel.setData(array);
			// oModel.setData({
			// 	EntryCollection: aEntries
			// });
		},

		chatApp: function () {

			if (!this.cBux) {
				// this.cBux = sap.ui.xmlfragment("E.E.fragments.cBux", this);
			}

			this.cBux.open();

		},
		itemAddJb: function (oEvent) {

			var that = this;
			var getData = this.getView().getModel('oTableModel').getData();
			// var nindex = oEvent.getSource().sId.split('-')[4];
			that.jbitempress = oEvent.getSource().sId.split('-')[4];
			// var dtset = getData[nindex];
			var dtset = getData[that.jbitempress];
			var obj = {
				Contract: dtset.Contract,
				Curr: dtset.Curr,
				Description: dtset.Description,
				GrossPrice: dtset.GrossPrice,
				Material: dtset.Material,
				PurchLine: dtset.PurchLine,
				PurchOrder: dtset.PurchOrder,
				Qnty: dtset.Qnty,
				RefNo: dtset.RefNo,
				ServType: dtset.ServType,
				Status: dtset.Status,
				UnitPrice: dtset.UnitPrice,
				Uom: dtset.Uom,
				VendorID: dtset.VendorID,
				Depth_From: "",
				Depth_To: "",
				Depth: "",
				Footage: "",
				Quantity: "",
				UOM: dtset.Uom,
				Unit_Price: dtset.UnitPrice,
				Gross_Price: "",
				Net_Price: "",
				Comment: "",
				StrtDate: "",
				Strt_tim: "",
				EndDate: "",
				End_tim: "",
				TVD_beg: "",
				ht_fac: "",
				POStartDate: dtset.POStartDate,
				POEndDate: dtset.POEndDate
			}
			var JBModel = new JSONModel(obj);
			that.getView().setModel(JBModel, "JBModel");
			that.JobLogging.setModel(JBModel, "JBModel");
			that.JobLoggingFormEquip.setModel(JBModel, "JBModel");

			// this.getView().getModel("JBModel").refresh(true);
			if (that.jbtype === "Crew") {
				that.JobLoggingCrew.open();
			} else if (that.jbtype === "Equipment") {
				that.JobLoggingFormEquip.open();
			} else if (that.jbtype === "Service") {
				that.JobLogging.open();
			} else if (that.jbtype === "Frack") {
				that.JobLoggingFrack.open();
			} else if (that.jbtype === "Non-Frack") {
				that.JobLoggingNonF.open();
			} else if (that.jbtype === "Personnel") {
				that.JobLoggingPersonal.open();
			}

		},

		onAddJb: function () {

			var getModel = this.getView().getModel('JBModel').getData();
			if (!this.JobLogging) {
				this.JobLogging = sap.ui.xmlfragment("E.E.fragments.JobLogging", this);
			}

			this.JobLogging.open();

		},
		JbEquip: function () {

			/////////////////////////
			//   timeFormatter: function (time) {
			//       var timeFormat = sap.ui.core.format.DateFormat.getTimeInstance({
			//             pattern: "HH:mm"
			//       });
			//       var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;

			//       if (time === null || typeof time === "undefined") {
			//             return "";
			//       }

			//       if (!isNaN(time)) {
			//             var timestr = timeFormat.format(new Date(time + TZOffsetMs));
			//             return timestr;
			//       }

			//       var timestr = timeFormat.format(new Date(time.ms + TZOffsetMs));
			//       return timestr;
			//},
			//              if (path.getPath() === "StartDate" || path.getPath() === "EndDate") {
			//       oValue = oValue.toLocaleDateString();
			//} else if (path.getPath() === "StartTime" || path.getPath() === "EndTime") {
			//       oValue = this.timeFormatter(oValue);
			//}

			////////////////////////////////////////////////
			var that = this;
			var getJBdATA = that.SrvHdrToItemsNav;
			var nidex = that.jbitempress;
			var getObjdata = getJBdATA[nidex];

			// var FirstObj = {
			// 	Docno: getObjdata.Docno,
			// 	// NonCharge: getObjdata,
			// 	// ItemVal: getObjdata,
			// 	VenPropQty: getObjdata.VenPropQty,
			// 	Mjahr: getObjdata.Mjahr,
			// 	Zeile: getObjdata.Zeile,
			// 	Jobid: "0001",
			// 	ContractNo: getObjdata.ContractNo,
			// 	ContractItem: getObjdata.ContractItem,
			// 	ContRef: getObjdata.ContRef,
			// 	// PoNo: getObjdata.PoNo,
			// 	PoNo: "6510090191",
			// 	// PoItem: getObjdata.PoItem,
			// 	PoItem: "00001",
			// 	PckgNo: "0000465041",
			// 	LineNo: "0000021228",
			// 	Txz01: getObjdata.Txz01,
			// 	Menge: getObjdata.Menge,
			// 	Meins: getObjdata.Meins,
			// 	InitialMenge: getObjdata.InitialMenge,
			// 	GrPrice: getObjdata.GrPrice,
			// 	Curr: getObjdata.Curr,
			// 	// Discount: getObjdata,
			// 	// Extrow: getObjdata,
			// 	DeleteInd: getObjdata.DeleteInd,
			// 	VendorAdd: "X",

			// 	// VendorDel: "",
			// 	// VenDelQty: "0.000",
			// 	JobLog: "JL0004",
			// 	SrcInd: "J",
			// 	VendorComments: "add"

			// }

			var jbobj = this.JobLogging.getModel("JBModel").getData();

			var obj = {
				Docno: that.detObj.Docno,
				Mjahr: that.detObj.Mjahr,
				Zeile: jbobj.RefNo,
				QtyVol: "10",
				JobId: "0001",
				Sno: "000",
				JobLog: "JL0004",
				JobLogDesc: "Services",
				Unit: jbobj.UOM,
				Currency: jbobj.Curr,
				UnitPrice: jbobj.UnitPrice,
				// Tvdbegin: jbobj.TVD_beg,
				GrossPrice: jbobj.Gross_Price,
				StartDate: jbobj.StrtDate,
				EndDate: jbobj.EndDate,
				// 	StartDate: "20230123" ,
				// EndDate: "20241022",
				StartTime: jbobj.Strt_tim,
				StartTime: "130000",
				// EndTime: jbobj.End_tim,
				EndTime: "170000",
				NetPrice: jbobj.Net_Price,
				// DepthFrom: jbobj.Depth_From,
				// DepthTo: jbobj.Depth_To,
				// Tvd: jbobj.TVD_beg,
				// HtFactor: jbobj.ht_fac,
				// Ernam: "",
				// Ersda: "20240321", //
				// Erzet: jbobj.Strt_tim, // HHMMSS
				// SummaryOpr: "",
				// MrDate: jbobj.StrtDate,
				// MrEndDate: jbobj.EndDate,
				// Tabname: "",
				DRSSJobloggingToTimesheetNav: [{

				}]

			};
			// var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/ZDWO_NX_VENDOR_SRV", true);
			// oModel.create("/JobLoggingServiceDataSet", FirstObj, {
			// 	success: function (oData, oResponse) {
			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/ZDWO_NX_VENDOR_SRV", true);
			oModel.create("/DRSSJobLoggingSet", obj, {
				success: function (oData, oResponse) {

					MessageBox.success("Success");
				},
				error: function (oError) {

					MessageBox.warning("Please Enter Valid Data");

				}
			});

			// },
			// error: function (oError) {
			// 	debugger;
			// 	MessageBox.warning("Error");

			// }
			// });
			// ZDWO_NX_VENDOR_SRV/DRSSJobLoggingSet 
			// var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/ZDWO_NX_VENDOR_SRV", true);
			// oModel.create("/DRSSJobLoggingSet", obj, {
			// 	success: function (oData, oResponse) {

			// 		debugger;
			// 	},
			// 	error: function (oError) {
			// 		debugger;
			// 		MessageBox.success("Job log duration should be within po validity dates From 00/00/0000 To 00/00/0000");

			// 	}
			// });

			this.JobLogging.close();
		},

		Jbclose: function () {
			this.JobLogging.close();
		},
		JbEquipclose: function () {
			this.JobLoggingFormEquip.close();
		},
		JbPersonalclose: function () {
			this.JobLoggingPersonal.close();
		},

		onCancelNotes: function () {
			this.cBux.close();
		},
		// HdrAttch: function () {
		// 	debugger;
		// 	if (!this.HdrAtt) {
		// 		this.HdrAtt = sap.ui.xmlfragment("E.E.fragments.HdrAtt", this);
		// 	}
		// 	this.HdrAtt.open();
		// },

		HdrAttch: function (oEvent) {
			// create dialog lazily

			// var sInputValue = oEvent.getSource().getValue();
			if (!this.HdrAtt) {
				this.HdrAtt = sap.ui.xmlfragment("E.E.fragments.HdrAtt", this);
			}

			this.HdrAtt.open();
			// if (!this._oDialog) {
			// 	Fragment.load({
			// 		name: "E.E.fragments.HdrAtt",
			// 		controller: this
			// 	}).then(function (oDialog) {
			// 		this._oDialog = oDialog;
			// 		this.getView().addDependent(oDialog);
			// 		this._oDialog.open();
			// 	}.bind(this));
			// } else {
			// 	this._oDialog.open();
			// }
		},
		onPressCancel: function () {
			var that = this;
			that.HdrAtt.close();
		},
		// onPressSendNest: function () {

		// 	this.HdrAtt.close();
		// },

		attachment: function (oEvent) {

			// sap.ui.core.BusyIndicator.show();
			var that = this;
			var getiD = oEvent.getSource().sId.split('-')[0];
			var nIndex = oEvent.getSource().sId.split('-')[2];
			that.nIndexHdrAtt = Number(nIndex);
			// that.Files = [];
			var controller = this;
			var oFileUploader = sap.ui.getCore().byId("fileUploader")
			var selectedFile = oEvent.getParameter("files")[0];
			var fileToLoad = oEvent.getParameter("files")[0];
			var fileReader = new FileReader();

			// var getseLECTED = that._oFragment_Multifile.getModel('oModelDoc').getData();
			// var attach = that.getView().getModel().oData;
			// let attacharray = Object.values(attach);

			// attacharray.forEach(function (item) {
			// 	if (that.getDt === item.DocNo) {

			// 		that.selectedObj = {
			// 			DocNo: item.DocNo,
			// 			FILESIZE: item.Filesize,
			// 			DOC_DATE: item.Erdat,
			// 			WELL_CODE: item.WellCode,
			// 			UPLOADED_BY: item.UploadedBy,
			// 			DRAFT_FLAG: item.DraftFlag,
			// 			RIG_CD: item.RigCd,
			// 			STATUS: item.Status,
			// 			vf_comments: "",
			// 			DocItem: ""
			// 		};
			// 	}
			// });

			var oFile = oEvent.getParameter("files")[0];

			that.fileObject = {};

			// that.fileObject.File = ""
			that.fileObject.Filename = oFile.name;
			that.fileObject.MIMEType = oFile.type;
			that.fileObject.Docno = "";
			// that.fileObject.Year = "";

			// that.fileObject.Filename = oFile.name;
			// that.fileObject.FileSize = oFile.size;
			this.readFileAsBase64(oFile, function (base64Content) {
				// var that = this;
				that.fileObject.FileValue = base64Content;
				if (getiD === "fileUploadertabHdr") { //////////////

					var getDataarray = sap.ui.getCore().byId("HdrAttchments").getModel("HdrFile").getData();
					getDataarray.forEach(function (obj, index) {
						if (index === that.nIndexHdrAtt) {
							Object.keys(that.fileObject).forEach(function (key) {
								obj[key] = that.fileObject[key];
							});
						}
					});
					var Attachlists = sap.ui.getCore().byId("Attachlist");
					sap.ui.getCore().byId("HdrAttchments").getModel("HdrFile").setData(getDataarray);
					that.AttachList = new JSONModel(that.Files);

				} else if (nIndex === "fileUploadertabJb") {

					var itemIndex = oEvent.getSource().sId.split('-')[6];
					var getDtaa = that.getView().getModel('actlogModel').getData()[itemIndex];
					that.fileObject.Docno = getDtaa.Docno
					that.fileObject.Mjahr = getDtaa.Mjahr
					that.fileObject.Zeile = getDtaa.Zeile
					that.fileObject.JobId = getDtaa.JobId
					that.fileObject.Sno = getDtaa.Sno

					that.FilesJb.push(that.fileObject);
				} else {
					var itemIndex = oEvent.getSource().sId.split('-')[4];
					var getDtaa = that.getView().getModel('oTableModel').getData()[itemIndex];
					that.fileObject.Zeile = getDtaa.ItemNo;
					that.Files.push(that.fileObject);
				}

			});

		},

		readFileAsBase64: function (file, callback) {
			var reader = new FileReader();
			reader.onload = function (event) {
				var base64Content = event.target.result.split(',')[1];
				callback(base64Content);
			};
			reader.readAsDataURL(file);
		},
		handleFileDelete: function (oEvent) {;
			var that = this;
			var Attachlist = sap.ui.getCore().byId("Attachlist");;
			var oItem = oEvent.getParameter("listItem"),
				sPath = oItem.getBindingContext("AttachList").getPath(),
				oIndex = sPath.split("/");
			that.Files.splice(oIndex[1], 1);

			var oListModel = new JSONModel(that.Files);
			Attachlist.setModel(oListModel, "AttachList");
		},
		mimeTypeToIcon: function (mimeType) {

			switch (mimeType) {
			case 'image/jpeg':
			case 'image/png':
			case 'image/gif':
				return 'sap-icon://picture';
			case 'application/pdf':
				return 'sap-icon://pdf-attachment';
			case 'text/plain':
				return 'sap-icon://document-text';
			case 'application/msword':
				return 'sap-icon://doc-attachment';
			case 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':
				return 'sap-icon://excel-attachment';
			case 'application/vnd.openxmlformats-officedocument.presentationml.presentation':
				return 'sap-icon://ppt-attachment';
				// Add more cases for other mime types and their corresponding icons
			default:
				return 'sap-icon://document';
			}
		},

		// loadMyFirstFragment: function () {
		// 	
		// 	if (!this.oMyFirstDialog) {
		// 		this.oMyFirstDialog = Fragment.load({
		// 			name: "E.E.fragments.cumBix"
		// 		}).then(function (oMyFirstDialog) {
		// 			return oMyFirstDialog;
		// 		});
		// 	}
		// },
		// CmntBx: function () {
		// 	
		// 	this.oMyFirstDialog.then(function (oDialog) {
		// 		oDialog.open();
		// 	});
		// },

		CmntBx: function () {

			if (!this.cumBix) {
				this.cumBix = sap.ui.xmlfragment("E.E.fragments.cumBix", this);
			}

			this.cumBix.open();
		},
		CumOk: function () {

			this.cumBix.getModel('remObj')
			this.cumBix.close();
		},
		CumClose: function () {
			this.cumBix.close();
		},

		attch: function (oEvent) {

			if (!this.atch) {
				this.atch = sap.ui.xmlfragment("E.E.fragments.atch", this);
			}

			this.atch.open();

		},
		onClose: function (e) {
			this.atch.close();
		},
		profile: function () {

			var that = this;
			if (!that.proFile) {
				that.proFile = sap.ui.xmlfragment("E.E.fragments.proFile", that);
				var oModel = that.getView().getModel("HeaderToRigNav")
					// that.proFile.setModel(that.getView().getModel("HeaderToRigNav"));
				that.proFile.setModel(oModel, "HeaderToRigNav");
				// 	var oModels = that.getView().getModel("WbsModel")
				// 	// that.proFile.setModel(that.getView().getModel("HeaderToRigNav"));
				// that.proFile.setModel(oModels, "WbsModel");

			}

			that.proFile.open();

		},
		onPFClose: function (e) {

			var that = this;
			// if (that.proFile) {
			// 	that.proFile.destroy();
			// }
			that.proFile.close();
		},
		PFloc: function (oEvent) {

			var array = [];

			var getVal = oEvent.getSource().getProperty('value');
			this.HeaderToWbsNav.forEach(function (oIndex) {
				var obj = {};
				if (getVal === oIndex.RigCode) {
					obj.RigCode = oIndex.RigCode;
					obj.Wbs = oIndex.Wbs;
					array.push(obj);

				} else {
					console.log('no WBS against this Remote Location')
				}

			});

			var OModel = new JSONModel();
			OModel.setData(array);
			this.proFile.setModel(OModel, 'WbsModel')

		},
		onPFSave: function () {

			// this.proFile.byId('Remote').getValue();
			// 	this.proFile.byId('WBS').getValue();
			// 		this.proFile.byId('vname').getValue();
			var rem = sap.ui.getCore().byId("Remote").getValue();
			var wbs = sap.ui.getCore().byId("WBS").getValue();
			var vname = sap.ui.getCore().byId("vname").getValue();
			var objSv = {
				FmanNid1: "TC_003",
				FmanName: "am",
				RigCd: rem,
				ChrAccNum: wbs,
				Role: "VENDOR",
				CRUD_FLG: "U"
			}

			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZDWO_NX_MASTER_SRV/", true);
			oModel.create("/Foreman_detSet", objSv, {
				success: function (success) {

				},
				error: function (oError) {

				}
			});

		},

		onBookPress: function (oEvent) {

			var that = this;
			var oButton = oEvent.getSource();
			var nindex = oButton.oPropagatedProperties.oBindingContexts.HeaderToItemsNav.sPath.split('/')[2]
			var gData = this.getView().getModel('HeaderToItemsNav').getData().cards[nindex];
			// oView = this.getView();
			if (!that.cd) {
				that.cd = sap.ui.xmlfragment("E.E.fragments.cd", that);

			}

			that.cd.open();
			that.cd.destroy

		},
		closeCard: function () {
			this.cd.close();
			this.cd.destroy;
		},

		status: function (sStatus) {

			if (sStatus == "Active") {
				return "Success";
			} else if (sStatus == "Pending") {
				return "Warning";

			} else if (sStatus == "Submitted") {
				return "Success";

			} else if (sStatus == "Draft") {
				return "Warning";

			} else if (sStatus == "Sos") {
				return "Warning";

			} else {
				return "Error";

			}
		},
		onAdd: function (oEvent) {

			var that = this;
			// let oIndex = oEvent.getSource().getBindingContext().sPath.split("/")[2];
			let oIndex = oEvent.getSource().oPropagatedProperties.oBindingContexts.HeaderToItemsNav.sPath.split('/')[2];
			let Nindex = Number(oIndex);

			that.HeaderToItemsNav[Nindex].Btn1 = "false";
			that.HeaderToItemsNav[Nindex].Btn2 = "true";
			that.getView().getModel("HeaderToItemsNav").setData(that.HeaderToItemsNav);
			that.getView().getModel("HeaderToItemsNav").setData({
				"cards": that.HeaderToItemsNav
			});

			let value = "0010";
			const array = that.tableList;
			array.forEach((item, index) => {
				value = String(Number(value) + 10).padStart(4, '0');
			});
			var oModel = that.getView().getModel("HeaderToItemsNav");
			var getData = oModel.getData().cards[oIndex]
			var objCrdToList = {
				Contract: getData.Contract,
				Curr: getData.Curr,
				Description: getData.Description,
				GrossPrice: getData.GrossPrice,
				History: getData.History,
				LineNo: getData.LineNo,
				Material: getData.Material,
				POStartDate: getData.POEndDate,
				POEndDate: getData.POStartDate,
				PckgNo: getData.PckgNo,
				PurchLine: getData.PurchLine,
				PurchOrder: getData.PurchOrder,
				Qnty: getData.Qnty,
				RefNo: getData.RefNo,
				ItemNo: value,
				ServType: getData.ServType,
				Status: getData.Status,
				UnitPrice: getData.UnitPrice,
				Uom: getData.Uom,
				VendorID: getData.VendorID,
				Comment: ""
			}

			that.tableList.push(objCrdToList);
			////////////////////////////////
			var Count = new JSONModel({
				count: that.tableList.length

			});
			that.getView().setModel(Count, "Count");

			// var oTableModel = new JSONModel(that.tableList);
			// that.getView().setModel(oTableModel, "oTableModel");

			that.getView().getModel('oTableModel').setData(that.tableList);

		},
		onRemove: function (oEvent) {

			var that = this;
			// let oIndex = oEvent.getSource().getBindingContext().sPath.split("/")[2];
			let oIndex = oEvent.getSource().oPropagatedProperties.oBindingContexts.HeaderToItemsNav.sPath.split('/')[2];
			let Nindex = Number(oIndex);

			const x = that.tableList.pop();

			console.log(`myArray values: ${that.tableList}`);

			that.HeaderToItemsNav[Nindex].Btn1 = "true";
			that.HeaderToItemsNav[Nindex].Btn2 = "false";
			that.getView().getModel("HeaderToItemsNav").setData(that.HeaderToItemsNav);
			that.getView().getModel("HeaderToItemsNav").setData({
				"cards": that.HeaderToItemsNav
			});

			var Count = new JSONModel({
				count: that.tableList.length

			});
			that.getView().setModel(Count, "Count");

			that.getView().getModel('oTableModel').setData(that.tableList);

		},

		deleteRow1: function (oEvent) {

			var that = this;
			// var getData = this.getView().getModel("oTableModel").oData;
			// var oIndex = oEvent.getParameters().listItem.sId.split('-')[2];
			var oIndex = oEvent.getParameters().id.split('-')[2];
			var getData = that.getView().getModel("oTableModel").getData().splice(oIndex, 1);
			that.getView().getModel("oTableModel").refresh(true);
			// this.getView().getModel("JBModel").refresh(true);
			var min = that.getView().getModel("Count").getData().count - 1
			var countobj = {

				count: min
			}
			that.getView().getModel("Count").setData(countobj);
			that.getView().getModel("Count").refresh(true);

			that.HeaderToItemsNav[oIndex].Btn1 = "true";
			that.HeaderToItemsNav[oIndex].Btn2 = "false";
			that.getView().getModel("HeaderToItemsNav").setData(that.HeaderToItemsNav);
			that.getView().getModel("HeaderToItemsNav").setData({
				"cards": that.HeaderToItemsNav
			});
			// var oTable = this.getView().byId("tableId2");
			// oTable.removeItem(oEvent.getParameter("listItem"));
		},
		deleteRow2: function (oEvent) {

			// var getHdrattData = sap.ui.getCore().byId("HdrAttchments").getModel("HdrFile").getData()
			// var oIndex = oEvent.getParameters().listItem.sId.split('-')[2];
			var oIndex = oEvent.getSource().oParent.sId.split('-')[2];
			// var getData = getHdrattData[oIndex]
			var getData = sap.ui.getCore().byId("HdrAttchments").getModel("HdrFile").getData().splice(oIndex, 1);
			sap.ui.getCore().byId("HdrAttchments").getModel("HdrFile").refresh(true);
		},
		OpenChat: function () {

			if (!this.cBux) {
				this.cBux = sap.ui.xmlfragment("E.E.fragments.cBux", this);
			}

			this.cBux.open();

		},
		remove: function (oEvent) {

			var oTable = this.getView().byId("tableId2");
			oTable.removeItem(oEvent.getSource().getParent());
		},
		deleteRow: function (oEvent) {
			var oTable = this.getView().byId("tableId2");
			oTable.removeItem(oEvent.getParameter("listItem"));
		},

		onNavToThirdPage: function () {

			var layoutPosition = this.getView().getModel("layoutMod").getData().layout;
			if (layoutPosition === this.oModel.MCFS) {
				this.getView().getModel("layoutMod").setProperty("/layout", this.oModel.TWCME);
				this.getView().byId("Chat").setVisible(true);
				// this.getOwnerComponent().getRouter().navTo('ThirdPage');
			} else if (layoutPosition === this.oModel.TWCME) {
				this.getView().byId("Chat").setVisible(false);
				this.getView().getModel("layoutMod").setProperty("/layout", this.oModel.MCFS);
				// this.getOwnerComponent().getRouter().navTo('ThirdPage');
			} else if (layoutPosition === this.oModel.TCME) {

				this.getView().getModel("layoutMod").setProperty("/layout", this.oModel.MCFS);
			}

		},
		onMenuPress: function () {

			var that = this;
			var layoutPosition = this.getView().getModel("layoutMod").getData().layout;
			if (layoutPosition === this.oModel.MCFS) {
				this.getView().getModel("layoutMod").setProperty("/layout", this.oModel.TWCME);
				// this.getView().byId("Chat").setVisible(true);
				// this.getOwnerComponent().getRouter().navTo('ThirdPage');
			} else if (layoutPosition === this.oModel.TWCME) {
				// this.getView().byId("Chat").setVisible(false);
				this.getView().getModel("layoutMod").setProperty("/layout", this.oModel.MCFS);
				// this.getOwnerComponent().getRouter().navTo('ThirdPage');
			} else if (layoutPosition === this.oModel.TCME) {

				this.getView().getModel("layoutMod").setProperty("/layout", this.oModel.MCFS);
			}

		},
		chat: function () {

			var that = this;
			var layoutPosition = this.getView().getModel("layoutMod").getData().layout;

			if (layoutPosition === this.oModel.TWCME) {
				this.getView().getModel("layoutMod").setProperty("/layout", this.oModel.TCME);
				this.getOwnerComponent().getRouter().navTo('ThirdPage');
			} else if (layoutPosition === this.oModel.TCME) {
				this.getView().getModel("layoutMod").setProperty("/layout", this.oModel.TWCME);
			} else if (layoutPosition === this.oModel.MCFS) {
				this.getView().getModel("layoutMod").setProperty("/layout", this.oModel.TCME);
			}
		},
		createSer: function () {

			// this.getView().getModel("layoutMod").setProperty("/layout", "MidColumnFullScreen");
			this.getOwnerComponent().getRouter().navTo('Fourth');
		},
		// 	onAddToCart: function (oEvent) {
		// 		
		// 	// var oResourceBundle = this.getModel("i18n").getResourceBundle();
		// 	var oProduct = oEvent.getSource().getBindingContext("view").getObject();
		// 	var oCartModel = this.getModel("cartProducts");
		// 	cart.addToCart(oResourceBundle, oProduct, oCartModel);
		// },

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf E.E.view.Detview
		 */
		onBeforeRendering: function () {

		},

		formatDate: function (sInput) {

			const dt = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "dd/MM/yyyy"
			});
			return dt.format(sInput);
		},
		formatTime: function (sInput) {

			if (sInput != null) {
				if (sInput.ms != undefined && sInput.ms != "") {

					var milliseconds = parseInt((sInput.ms % 1000) / 100),
						seconds = parseInt((sInput.ms / 1000) % 60),
						minutes = parseInt((sInput.ms / (1000 * 60)) % 60),
						hours = parseInt((sInput.ms / (1000 * 60 * 60)) % 24);

					hours = (hours < 10) ? "0" + hours : hours;
					minutes = (minutes < 10) ? "0" + minutes : minutes;
					seconds = (seconds < 10) ? "0" + seconds : seconds;

					return hours + ":" + minutes + ":" + seconds;
				}
			}
		},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf E.E.view.Detview
		 */

		onAfterRendering: function () {

			this.getView().byId("TopVBox1").setVisible(false);
			this.timeSheet = sap.ui.xmlfragment("E.E.fragments.timeSheet", this);
			this.EticketPreview = sap.ui.xmlfragment("E.E.fragments.EticketPreview", this);
			var HeaderModel = new JSONModel();
			this.getView().setModel(HeaderModel, "HeaderModel");

			var remObj = {
				"Remarks": ""
			};
			var remObj = new JSONModel(remObj);
			this.cumBix = sap.ui.xmlfragment("E.E.fragments.cumBix", this);
			this.cumBix.setModel(remObj, "remObj");

			var oTableModel = new JSONModel();
			this.getView().setModel(oTableModel, "oTableModel");

			this.ProFileAttach = sap.ui.xmlfragment("E.E.fragments.ProFileAttach", this);
			var HdrProObJ = [{
					"Header": "Header",
					"Valid_till": "",
					"Valid_from": ""

				}, {
					"Header": "Footer",
					"Valid_till": "",
					"Valid_from": ""
				}, {
					"Header": "Signature",
					"Valid_till": "",
					"Valid_from": ""
				}, {
					"Header": "Saudization Certificate",
					"Valid_till": "",
					"Valid_from": ""
				}, {
					"Header": "VAT Certificate",
					"Valid_till": "",
					"Valid_from": ""
				}

			]

			var oProModel = new JSONModel(HdrProObJ);
			sap.ui.getCore().byId("ProAttchments").setModel(oProModel, "oProModel");

			this.JobLogging = sap.ui.xmlfragment("E.E.fragments.JobLoggingForm", this); //service
			this.JobLoggingCrew = sap.ui.xmlfragment("E.E.fragments.JobLoggingFormCrew", this); //Crew
			this.JobLoggingFormEquip = sap.ui.xmlfragment("E.E.fragments.JobLoggingFormEquip", this); //Equip
			this.JobLoggingNonF = sap.ui.xmlfragment("E.E.fragments.JobLoggingNonF", this); //Non-Frack
			this.JobLoggingFrack = sap.ui.xmlfragment("E.E.fragments.JobLoggingFrack", this); //Frach
			this.JobLoggingPersonal = sap.ui.xmlfragment("E.E.fragments.JobLoggingPersonal", this); //personal

			var HdrFile = [{

				"FileValue": "",
				"Filename": "",
				"MIMEType": "",
				"Docno": "",
				"Year": "",

			}];
			var HdrFile = new JSONModel(HdrFile);
			this.HdrAtt = sap.ui.xmlfragment("E.E.fragments.HdrAtt", this);
			sap.ui.getCore().byId("HdrAttchments").setModel(HdrFile, "HdrFile");

			// this.HeaderToCountNav
			// var Draft = "67";
			// var a = "Draft :  '" + Draft + "' ,  Submitted : 78,  Ready to do Job : 50,  Job Logging : 35,  Released : 34 ";
			// this.byId("idScrollText").setContent('<marquee style="font-size: 1.0rem;color: black;font-weight: bold">' + a + '</marquee>');

			this.getView().byId('sapFShellBarSample')._oSearch.mProperties.icon = 'sap-icon://action-settings'
			this.getView().byId('sapFShellBarSample')._oSearch.mProperties.text = 'Profile'
			var that = this;
			this.oModel = {
				"TCME": "ThreeColumnsMidExpanded",
				"MCFS": "MidColumnFullScreen",
				"TWCME": "TwoColumnsMidExpanded",

			};

			var oModel1 = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oModel1, "ChatObj");

			// var obj = {
			// 	"VendorID": "",
			// 	"HeaderToItemsNav": [{

			// 	}],
			// 	"HeaderToRigNav": [{

			// 	}],
			// 	"HeaderToWbsNav": [{

			// 	}]
			// }

			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/ZDWO_NX_VENDOR_SRV", true);
			// HeaderSet(VendorID = '') ? $expand = HeaderToRigNav, HeaderToWbsNav, HeaderToItemsNav
			// var sPath = "ZUR_AttFile_ItemsSet?$filter=DocNo eq '" + that.selecteddata.Doc_number + "'";

			// var sPath = "HeaderSet(VendorID='')?sap-client=025&$expand=HeaderToRigNav,HeaderToWbsNav,HeaderToItemsNav";
			// var sPath = "/HeaderSet(HeaderToRigNav='" + that._category + "',HeaderToWbsNav='" + oTile + "',HeaderToItemsNav='" + that._supplier +
			// 	"';
			// var EmpDetails = "HeaderToRigNav,HeaderToWbsNav,HeaderToItemsNav";
			var VendorID = "";
			sap.ui.core.BusyIndicator.show();
			oModel.read("/HeaderSet(VendorID='" + VendorID + "')", {
				urlParameters: {
					"$expand": "HeaderToRigNav,HeaderToWbsNav,HeaderToItemsNav,HeaderToPriorNav,HeaderToPoNav,HeaderToCountNav,HdrtoVendorAttachNav"
				},
				success: function (oData, oResponse) {
					that.HeaderToWbsNav = oResponse.data.HeaderToWbsNav.results
					var HeaderToWbsNav = new JSONModel();
					HeaderToWbsNav.setData(that.HeaderToWbsNav);
					that.oView.setModel(HeaderToWbsNav, 'HeaderToWbsNav')

					that.HeaderToCountNav = oResponse.data.HeaderToCountNav.results
					var HeaderToCountNav = new JSONModel();
					HeaderToCountNav.setData(that.HeaderToCountNav);
					that.oView.setModel(HeaderToCountNav, 'HeaderToCountNav')
					var Ready = "";
					var Draft = "";
					var Submitted = "";
					var joblogging = "";
					var released = "";
					that.HeaderToCountNav.forEach(function (index) {
						if (index.Rqstat === "RTDJ") {
							Ready = index.Count
						} else if (index.Rqstat === "VINT") {
							Draft = index.Count
						} else if (index.Rqstat === "SUBT") {
							Submitted = index.Count
						} else if (index.Rqstat === "JOBL") {
							joblogging = index.Count
						} else if (index.Rqstat === "RECL") {
							released = index.Count
						}
					});
					var Draft = "67";
					var a = "Draft :('" + Draft + "') ,  Submitted :('" + Submitted + "') ,  Ready to do Job :('" + Ready +
						"'),  Job Logging :('" + joblogging + "'),  Released : ('" + released + "')";
					that.byId("idScrollText").setContent('<marquee style="font-size: 1.0rem;color: black;font-weight: bold">' + a + '</marquee>');

					that.HeaderToPoNav = oResponse.data.HeaderToPoNav.results
					var HeaderToPoNav = new JSONModel();
					HeaderToPoNav.setData(that.HeaderToPoNav);
					that.oView.setModel(HeaderToPoNav, 'HeaderToPoNav')

					that.HeaderToPriorNav = oResponse.data.HeaderToPriorNav.results
					var HeaderToPriorNav = new JSONModel();
					HeaderToPriorNav.setData(that.HeaderToPriorNav);
					that.oView.setModel(HeaderToPriorNav, 'HeaderToPriorNav')

					that.HeaderToItemsNav = oResponse.data.HeaderToItemsNav.results
						// var HeaderToItemsNav = new JSONModel();
						// HeaderToItemsNav.setData(that.HeaderToItemsNav);
						// HeaderToItemsNav.setData({
						// 	"cards": that.HeaderToItemsNav
						// });
						// that.oView.setModel(HeaderToItemsNav)

					that.HeaderToRigNav = oResponse.data.HeaderToRigNav.results
					var HeaderToRigNav = new JSONModel();
					HeaderToRigNav.setData(that.HeaderToRigNav);
					that.oView.setModel(HeaderToRigNav, 'HeaderToRigNav')

					that.vendorObj.VendorID = oResponse.data.VendorID;
					that.vendorObj.VendorName = oResponse.data.VendorName;
					that.vendorObj.WellName = oResponse.data.WellName;
					that.vendorObj.VendorDetails = oResponse.data.VendorDetails;

					var vendorObj = new JSONModel();
					vendorObj.setData(that.vendorObj);
					that.oView.setModel(vendorObj, 'vendorObj')

					that.DetailObj.But1Text = oData.But1Text;
					that.DetailObj.But1Visible = oData.But1Visible;
					that.DetailObj.But2Text = oData.But2Text;
					that.DetailObj.But2Visible = oData.But2Visible;

					that.DetailObj.But3Text = oData.But3Text;
					that.DetailObj.But3Visible = oData.But3Visible;

					that.DetailObj.But4Text = oData.But4Text;
					that.DetailObj.But4Visible = oData.But4Visible;

					var DetailObj = new JSONModel();
					DetailObj.setData(that.DetailObj);
					that.oView.setModel(DetailObj, 'DetailObj')
					sap.ui.core.BusyIndicator.hide();
				},
				error: function (oData, response) {
					var data = oData.results;
					MessageBox.warning("Data Load Error");
					sap.ui.core.BusyIndicator.hide();

				}
			});

		},

		// 		https://cs-010100.aramco.com.sa:1443/sap/opu/odata/sap/ZDWO_NX_VENDOR_SRV/JobLoggingServiceDataSet
		// {
		// "Docno" : "3000002569",
		// "NonCharge": "false" ,
		// "ItemVal" : "0.00",
		// "VenPropQty" : "0.000",
		// "Mjahr" : "2023",
		// "Zeile" : "0070",
		// "Jobid" : "0001",
		// "ContractNo" : "6600003651",
		// "ContractItem" : "00001",
		// "ContRef" : "02.20",
		// "PoNo" : "6510089617",
		// "PoItem" : "00001",
		// "PckgNo" : "0000465041",
		// "LineNo" : "0000021228",
		// "Txz01" : "Gyro MWD: H/S 16 - 17?", 
		// "Menge" : "5.000",
		// "Meins" : "HR",
		// "InitialMenge" : "5.000",
		// "GrPrice" : "100.00",
		// "Curr" : "SAR",
		// "Discount" : "0.000",
		// "Extrow" : "0000000000",
		// "DeleteInd" : "",
		// "VendorAdd": "X",
		// "VendorDel" : "",
		// "VenDelQty" : "0.000",
		// "JobLog" : "JL0004",
		// "SrcInd" : "J",
		// "VendorComments" : "add"
		// }
		// POStartDate
		// POEndDate 

	});

});