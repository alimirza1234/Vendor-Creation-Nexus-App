sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/format/DateFormat",
], function (Controller, DateFormat) {
	"use strict";

	return Controller.extend("E.E.controller.ThirdPage", {
		comnt: [],
		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf E.E.view.ThirdPage
		 */
		onInit: function () {
		
		},

		onNavToThirdPage: function () {
		
			this.getView().getModel("layoutMod").setProperty("/layout", "ThreeColumnsEndExpanded");
			this.getOwnerComponent().getRouter().navTo('ThirdPage');
		},
		onPost: function (oEvent) {
		
			var that = this;
			var oFormat = DateFormat.getDateTimeInstance({
				style: "medium"
			});
			var oDate = new Date();
			var sDate = oFormat.format(oDate);
			// create new entry
			var sValue = this.getView().byId('idInputContent').getValue();
			var oEntry = {
				Author: "SY_UNAME",
				Type: "Reply",
				Date: "" + sDate,
				Text: sValue
			};

			// update model
			// var array = []
			// var oModel = new JSONModel();
			var oModel1 = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oModel1, "ChatObj");
			var oModel = this.getView().getModel("ChatObj");
			// 	var aEntries = array;
			that.comnt.unshift(oEntry);
			oModel.setData(that.comnt);
			this.getView().setModel(oModel, "ChatObj")
			this.getView().getModel("ChatObj").refresh;
			// this.getView().setModel(oModel);
			// var aEntries = array;
			// array.unshift(oEntry);
			// oModel.setData(array);
			// oModel.setData({
			// 	EntryCollection: aEntries
			// });
		},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf E.E.view.ThirdPage
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf E.E.view.ThirdPage
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf E.E.view.ThirdPage
		 */
		//	onExit: function() {
		//
		//	}

	});

});