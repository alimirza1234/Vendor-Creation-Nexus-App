sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function (Controller, JSONModel) {
	"use strict";

	return Controller.extend("E.E.controller.Master", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf E.E.view.Master
		 */
		onInit: function () {

			var abc = [{
					"text": "INBOX",
					"ref": "sap-icon://inbox",

					"nodes": [

						{
							"text": "Draft",
							"Code": "VINT",
							"ref": "sap-icon://activity-assigned-to-goal"

						}, {
							"text": "Submitted",
							"Code": "SUBT",
							"ref": "sap-icon://add-process"

						}, {
							"text": "Ready To Do Job",
							"Code": "RTDJ",
							"ref": "sap-icon://begin"

						},

						{
							"text": "Job Logging",
							"Code": "JOBL",
							"ref": "sap-icon://add-activity"

						}, {
							"text": "Released",
							"Code": "RELS",
							"ref": "sap-icon://complete"

						}, {
							"text": "Recall",
							"Code": "RECL",
							"ref": "sap-icon://complete"

						}, {
							"text": "Delete",
							"Code": "DELT",
							"ref": "sap-icon://clear-filter"
						}

					]
				},

			]

			var oModel = new JSONModel(abc);
			this.getView().setModel(oModel, "List");
		},

		inboxpress: function () {
	
		},

		test: function (oEvent) {
	
			var nindex = oEvent.getSource().oBindingContexts.List.sPath.split('/')[3];
			var getAction = oEvent.getSource().getProperty('title');
			var getData = oEvent.getSource().oBindingContexts.List.oModel.oData[0].nodes[nindex];

			if (getAction === "Service Creation") {
				var loRouter = sap.ui.core.UIComponent.getRouterFor(this);
				loRouter.navTo("Inbox", {
					types: "Service Creation"

				});
				// this.getOwnerComponent().getRouter().navTo('Inbox');
			} else if (getAction === "Draft") {

				var loRouter = sap.ui.core.UIComponent.getRouterFor(this);
				loRouter.navTo("Inbox", {
					types: "Draft",
					Code: "VINT"

				});

			} else if (getAction === "Submitted") {

				var loRouter = sap.ui.core.UIComponent.getRouterFor(this);
				loRouter.navTo("Inbox", {
					types: "Submitted",
					Code: "SUBT"

				});

			} else if (getAction === "Ready To Do Job") {

				var loRouter = sap.ui.core.UIComponent.getRouterFor(this);
				loRouter.navTo("Inbox", {
					types: "Ready To Do Job",
					Code: "RTDJ"

				});

			} else if (getAction === "Job Logging") {
				var loRouter = sap.ui.core.UIComponent.getRouterFor(this);
				loRouter.navTo("Inbox", {
					types: "Job Logging",
					Code: "JOBL"

				});
			} else if (getAction === "Released") {
				var loRouter = sap.ui.core.UIComponent.getRouterFor(this);
				loRouter.navTo("Inbox", {
					types: "Released",
					Code: "RELS"

				});
			} else if (getAction === "Proposed Service") {
				var loRouter = sap.ui.core.UIComponent.getRouterFor(this);
				loRouter.navTo("Inbox", {
					types: "Proposed Service"

				});
			}
		}

	});

});