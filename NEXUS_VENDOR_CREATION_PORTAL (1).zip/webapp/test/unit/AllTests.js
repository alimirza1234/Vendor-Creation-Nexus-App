sap.ui.define([
	"E/E/test/unit/controller/App.controller"
], function () {
	"use strict";
});