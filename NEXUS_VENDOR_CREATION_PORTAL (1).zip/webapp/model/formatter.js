sap.ui.define([], function () {
	"use strict";
	return {
		status: function (sStatus) {

			if (sStatus == "Approved") {
				return "Success";
			} else if (sStatus == "Rejected") {
				return "Warning";

			} else if (sStatus == "Sos") {
				return "Warning";

			} else {
				return "Success";

			}
		},
		curr: function (sStatus) {

			if (sStatus == "SAR") {
				return "Error";
			} else if (sStatus == "PKR") {
				return "Warning";

			} else if (sStatus == "Submitted") {
				return "Success";

			} else if (sStatus == "Sos") {
				return "Warning";

			} else {
				return "Error";

			}
		}

	};
});